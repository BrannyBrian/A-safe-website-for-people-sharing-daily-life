const FX = require("./functions"),
  Database = require("mongodb").Db,
  MongoClient = require("mongodb").MongoClient,
  express = require("express"),
  cors = require("cors"),
  fileUpload = require("express-fileupload"),
  handlebars = require("express-handlebars").create({
    defaultLayout: "index",
    layoutsDir: __dirname + "/views/layouts",
  }),
  expressApplication = express();

const ApplicationName = "SocialApp",
  ServerPort = 8000,
  DatabaseUri =
    "mongodb+srv://waferick:waferick@cluster0.ndgnmjz.mongodb.net/?retryWrites=true&w=majority",
  DatabaseName = "SocialAppV1";

function getDatabaseFromUri(
  uri,
  name,
  clientOptions,
  databaseOptions,
  callback
) {
  return MongoClient.connect(uri, clientOptions).then((client) => {
    callback(client.db(name, databaseOptions));
  });
}

function initializeApplication() {
  expressApplication.use(cors());
  expressApplication.use(fileUpload({ limits: { fileSize: 1 * 1024 * 1024 } }));
  expressApplication.use(
    express.urlencoded({
      extended: true,
    })
  );
  expressApplication.use(express.json({}));
  expressApplication.use(
    "/static",
    express.static(__dirname + "/static", {
      maxAge: "10000",
      etag: true,
    })
  );
  expressApplication.engine("handlebars", handlebars.engine);
  expressApplication.set("view engine", "handlebars");
}

async function logRequest(response) {
  let request = response.req;
  if (request) {
    let log = `${request.protocol} : ${request.method} : ${JSON.stringify(
      request.subdomains
    )} : ${request.hostname} : `;
    log += `${request.originalUrl} : ${Date.now()} : ${JSON.stringify(
      request.ips
    )}`;
    console.log(log);
  }
}

function sendJsonResponse(response, json) {
  logRequest(response);
  response.json(json);
  response.end();
}

function renderUITemplate(response) {
  response.render("UI", { layout: "layout" });
}

function routeApplication(database = new Database()) {
  expressApplication.get("/", async (request, response) => {
    renderUITemplate(response);
  });
  expressApplication.post("/", async (request, response) => {
    let requestedAction = request.body.request;
    if (requestedAction) {
      let functionKey = FX.handlers[requestedAction];
      if (functionKey && typeof functionKey === "function") {
        functionKey(database, request, response);
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Invalid request!",
        });
      }
    } else {
      sendJsonResponse(response, {
        status: "error",
        message: "Missing request!",
      });
    }
  });
}

function runApplication() {
  getDatabaseFromUri(DatabaseUri, DatabaseName, {}, {}, (database) => {
    if (database !== null) {
      console.log("Database connected.");
      initializeApplication();
      routeApplication(database);
      expressApplication.listen(ServerPort, "0.0.0.0", 10, () => {
        console.log(ApplicationName + " server running at port " + ServerPort);
      });
    } else {
      console.error("Could not connect to database!!");
    }
  });
}

runApplication();
