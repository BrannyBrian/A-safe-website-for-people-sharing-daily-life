const Database = require("mongodb").Db,
  Collection = require("mongodb").Collection,
  MongoClient = require("mongodb").MongoClient,
  ObjectID = require("bson").ObjectId,
  express = require("express"),
  cors = require("cors"),
  crypto = require("crypto"),
  jwt = require("jsonwebtoken"),
  fs = require("fs");

const ApplicationName = "SocialApp",
  ServerPort = 8000,
  DatabaseUri =
    "mongodb+srv://waferick:waferick@cluster0.ndgnmjz.mongodb.net/?retryWrites=true&w=majority",
  DatabaseName = "SocialAppV1",
  DatabaseCollections = {
    Users: "Users",
    FriendRequests: "FriendRequests",
    Posts: "Posts",
    Comments: "Comments",
    MediaFiles: "MediaFiles",
    Notifications: "Notifications",
  };

const FileSizesMB = {
    Reference: 1024 * 1024,
    Image: 0.5,
    Video: 1,
  },
  JwtSecretKey =
    "54d96a9a-ad64-4aff-8b01-0ff61d7ea82eaa276d03-9530-4520-b6f1-97db73975ebf936c9c46-7023-4ed6-83ff-9bbd95f21ce6",
  Requests = {
    SignIn: "signIn",
    SignUp: "signUp",
    UpdateProfile: "updateProfile",
    DeleteAccount: "deleteAccount",
    CreateFriendRequest: "createFriendRequest",
    CancelFriendRequest: "cancelFriendRequest",
    AcceptFriendRequest: "acceptFriendRequest",
    RejectFriendRequest: "rejectFriendRequest",
    GetFriendRequests: "getFriendRequests",
    GetPosts: "getPosts",
    GetPost: "getPost",
    CreatePost: "createPost",
    UpdatePost: "updatePost",
    DeletePost: "deletePost",
    CreateComment: "createComment",
    DeleteComment: "deleteComment",
    GetPeople: "getPeople",
    GetPerson: "getPerson",
    FollowPerson: "followPerson",
    UnfollowPerson: "unfollowPerson",
    BlockPerson: "blockPerson",
    UnBlockPerson: "unblockPerson",
  };

const ProfileVisibility = {
    Public: "public",
    Friends: "friends",
    Followers: "followers",
    FriendsAndFollowers: "friends_and_followers",
  },
  FriendRequestStatus = {
    Pending: "pending",
    Accepted: "accepted",
    Rejected: "rejected",
    Cancelled: "cancelled",
  },
  PostVisibility = {
    Public: "public",
    Friends: "friends",
    Followers: "followers",
    FriendsAndFollowers: "friends_and-followers",
  };

function User(data) {
  let model = {
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    password: "",
    country: "",
    address: "",
    phoneNumber: "",
    friendsIds: [],
    followersIds: [],
    followingIds: [],
    blockedIds: [],
    profileVisibility: "",
    profileImageId: "",
    ...data,
    deleted: false,
  };
  return model;
}

function FriendRequest(data) {
  let model = {
    sender: {
      username: "",
      profileImageId: "",
    },
    senderId: "",
    receiverId: "",
    status: "",
    ...data,
    deleted: false,
  };
  return model;
}

function Post(data) {
  let model = {
    user: {
      username: "",
      profileImageId: "",
    },
    userId: "",
    title: "",
    text: "",
    imagesIds: [],
    videosIds: [],
    commentsIds: [],
    visibility: "",
    ...data,
    deleted: false,
  };
  return model;
}

function Comment(data) {
  let model = {
    user: {
      username: "",
      profileImageId: "",
    },
    userId: "",
    text: "",
    ...data,
    deleted: false,
  };
  return model;
}

function Notification(data) {
  let model = {
    userId: "",
    title: "",
    text: "",
    ...data,
    deleted: false,
  };
  return model;
}

function generateJwtToken(data) {
  return jwt.sign(data, JwtSecretKey);
}

function decodeJwtToken(data) {
  return jwt.verify(data, JwtSecretKey);
}

function hashString(string) {
  return crypto.createHash("md5").update(string).digest("hex");
}

function validateEmailRE(string) {
  return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(string);
}

function getObjectID(id = "") {
  try {
    return new ObjectID(id);
  } catch (e) {
    return new ObjectID("000000000000000000000000");
  }
}

function getCurrentUser(database, request, callback) {
  let Authorization = request.header("Authorization");
  if (Authorization) {
    let userData = decodeJwtToken(Authorization),
      usersCollection = database.collection(DatabaseCollections.Users);
    if (userData && typeof userData === "object" && !Array.isArray(userData)) {
      usersCollection
        .findOne({
          _id: getObjectID(userData.userId),
          username: userData.username,
          email: userData.email,
        })
        .then((user) => {
          callback(user);
        });
    } else {
      callback(null);
    }
  } else {
    callback(null);
  }
}

async function logRequest(response) {
  let request = response.req;
  if (request) {
    let log = `${request.protocol} : ${request.method} : ${JSON.stringify(
      request.subdomains
    )} : ${request.hostname} : `;
    log += `${request.originalUrl} : ${Date.now()} : ${JSON.stringify(
      request.ips
    )}`;
    console.log(log);
  }
}

function sendJsonResponse(response, json) {
  logRequest(response);
  response.json(json);
  response.end();
}

exports.handlers = {
  signIn(database = new Database(), request, response) {
    let { email, password } = request.body,
      usersCollection = database.collection(DatabaseCollections.Users);
    usersCollection
      .findOne({
        email: email,
        password: hashString(password),
        deleted: false,
      })
      .then((user) => {
        if (user) {
          sendJsonResponse(response, {
            status: "success",
            message: "Sign in successful.",
            user: user,
            jwtToken: generateJwtToken({
              userId: user._id,
              username: user.username,
              email: user.email,
            }),
          });
        } else {
          sendJsonResponse(response, {
            ststus: "error",
            message: "Invalid credentials!",
          });
        }
      });
  },
  signUp(database = new Database(), request, response) {
    let {
        firstName,
        lastName,
        email,
        username,
        address,
        country,
        phoneNumber,
        password,
      } = request.body,
      usersCollection = database.collection(DatabaseCollections.Users);
    usersCollection
      .findOne({
        $or: [{ username: username }, { email: email }],
      })
      .then((duplicate) => {
        if (duplicate) {
          sendJsonResponse(response, {
            status: "error",
            message: "A user with the same username or email exists!",
          });
        } else {
          let user = User({
            firstName,
            lastName,
            email,
            username,
            address,
            country,
            phoneNumber,
          });
          user.password = hashString(password);
          usersCollection.insertOne(user).then((result) => {
            sendJsonResponse(response, {
              status: "success",
              message: "Sign up successful.",
              user: {
                ...user,
                _id: result.insertedId,
              },
              jwtToken: generateJwtToken({
                userId: result.insertedId,
                username: user.username,
                email: user.email,
              }),
            });
          });
        }
      });
  },
  updateProfile(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let {
            firstName,
            lastName,
            email,
            username,
            address,
            country,
            phoneNumber,
            password,
          } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        let update = () => {
          Object.assign(currentUser, {
            firstName,
            lastName,
            email,
            username,
            address,
            country,
            phoneNumber,
          });
          if (password) {
            currentUser.password = hashString(password);
          }
          usersCollection
            .updateOne({ _id: currentUser._id }, { $set: currentUser })
            .then((result) => {
              sendJsonResponse(response, {
                status: "success",
                message: "Profile update successful.",
                user: currentUser,
                jwtToken: generateJwtToken({
                  userId: currentUser._id,
                  username: currentUser.username,
                  email: currentUser.email,
                }),
              });
            });
        };
        if (username !== currentUser.username || email !== currentUser.email) {
          usersCollection
            .findOne({
              $or: [{ username: username }, { email: email }],
              _id: { $ne: currentUser._id },
            })
            .then((duplicate) => {
              if (duplicate) {
                sendJsonResponse(response, {
                  status: "error",
                  message: "A user with the same username or email exists!",
                });
              } else {
                update();
              }
            });
        } else {
          update();
        }
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  deleteAccount(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let usersCollection = database.collection(DatabaseCollections.Users);
        currentUser.deleted = true;
        usersCollection
          .updateOne({ _id: currentUser._id }, { $set: currentUser })
          .then((result) => {
            sendJsonResponse(response, {
              status: "success",
              message: "Account deleted",
            });
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  createFriendRequest(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body;
        if (userId) {
          let usersCollection = database.collection(DatabaseCollections.Users),
            friendRequestsCollection = database.collection(
              DatabaseCollections.FriendRequests
            );
          usersCollection
            .findOne({
              _id: getObjectID(userId),
            })
            .then((user) => {
              if (user) {
                let friendRequest = FriendRequest({
                  sender: {
                    username: currentUser.username,
                    profileImageId: currentUser.profileImageId,
                  },
                  senderId: currentUser._id,
                  receiverId: user._id,
                  status: FriendRequestStatus.Pending,
                });
                friendRequestsCollection
                  .insertOne(friendRequest)
                  .then((result) => {
                    sendJsonResponse(response, {
                      status: "success",
                      message: "Friend request sent!",
                      friendRequest: {
                        ...friendRequest,
                        _id: result.insertedId,
                      },
                    });
                  });
              } else {
                sendJsonResponse(response, {
                  status: "error",
                  message: "Error retrieving user!",
                });
              }
            });
        } else {
          sendJsonResponse(response, {
            status: "error",
            message: "Missing userId!",
          });
        }
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  cancelFriendRequest(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { requestId } = request.body;
        if (requestId) {
          let usersCollection = database.collection(DatabaseCollections.Users),
            friendRequestsCollection = database.collection(
              DatabaseCollections.FriendRequests
            );
          friendRequestsCollection
            .findOne({
              _id: getObjectID(requestId),
              senderId: currentUser._id,
              status: FriendRequestStatus.Pending,
              deleted: false,
            })
            .then((friendRequest) => {
              if (friendRequest) {
                friendRequest.status = FriendRequestStatus.Cancelled;
                friendRequestsCollection
                  .updateOne(
                    { _id: friendRequest._id },
                    { $set: friendRequest }
                  )
                  .then((result) => {
                    sendJsonResponse(response, {
                      status: "success",
                      message: "Friend request cancelled.",
                    });
                  });
              } else {
                sendJsonResponse(response, {
                  status: "error",
                  message: "Error retrieving request!",
                });
              }
            });
        } else {
          sendJsonResponse(response, {
            status: "error",
            message: "Missing requestId!",
          });
        }
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  acceptFriendRequest(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { requestId } = request.body;
        if (requestId) {
          let usersCollection = database.collection(DatabaseCollections.Users),
            friendRequestsCollection = database.collection(
              DatabaseCollections.FriendRequests
            );
          friendRequestsCollection
            .findOne({
              _id: getObjectID(requestId),
              receiverId: currentUser._id,
              status: FriendRequestStatus.Pending,
              deleted: false,
            })
            .then((friendRequest) => {
              if (friendRequest) {
                friendRequest.status = FriendRequestStatus.Accepted;
                friendRequestsCollection
                  .updateOne(
                    { _id: friendRequest._id },
                    { $set: friendRequest }
                  )
                  .then((result) => {
                    usersCollection
                      .findOne({ _id: getObjectID(friendRequest.senderId) })
                      .then((user) => {
                        if (user) {
                          currentUser.friendsIds = Array.from([
                            ...currentUser.friendsIds,
                            user._id,
                          ]);
                          user.friendsIds = Array.from([
                            ...user.friendsIds,
                            currentUser._id,
                          ]);
                          usersCollection.updateOne(
                            { _id: user._id },
                            { $set: user }
                          );
                          usersCollection
                            .updateOne(
                              { _id: currentUser._id },
                              { $set: currentUser }
                            )
                            .then((result) => {
                              sendJsonResponse(response, {
                                status: "success",
                                message: "Friend request accepted!",
                                user: currentUser,
                                friendRequest: friendRequest,
                              });
                            });
                        } else {
                          sendJsonResponse(response, {
                            status: "error",
                            message: "Error retrieving user!",
                          });
                        }
                      });
                  });
              } else {
                sendJsonResponse(response, {
                  status: "error",
                  message: "Error retrieving request!",
                });
              }
            });
        } else {
          sendJsonResponse(response, {
            status: "error",
            message: "Missing requestId!",
          });
        }
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  rejectFriendRequest(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { requestId } = request.body;
        if (requestId) {
          let usersCollection = database.collection(DatabaseCollections.Users),
            friendRequestsCollection = database.collection(
              DatabaseCollections.FriendRequests
            );
          friendRequestsCollection
            .findOne({
              _id: getObjectID(requestId),
              receiverId: currentUser._id,
              status: FriendRequestStatus.Pending,
              deleted: false,
            })
            .then((friendRequest) => {
              if (friendRequest) {
                friendRequest.status = FriendRequestStatus.Rejected;
                friendRequestsCollection
                  .updateOne(
                    { _id: friendRequest._id },
                    { $set: friendRequest }
                  )
                  .then((result) => {
                    sendJsonResponse(response, {
                      status: "success",
                      message: "Friend request rejected!",
                      friendRequest: friendRequest,
                    });
                  });
              } else {
                sendJsonResponse(response, {
                  status: "error",
                  message: "Error retrieving request!",
                });
              }
            });
        } else {
          sendJsonResponse(response, {
            status: "error",
            message: "Missing requestId!",
          });
        }
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  getFriendRequests(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { search } = request.body,
          friendRequestsCollection = database.collection(
            DatabaseCollections.FriendRequests
          );
        friendRequestsCollection
          .find({
            deleted: false,
            $or: [
              { senderId: currentUser._id },
              { receiverId: currentUser._id },
            ],
          })
          .toArray()
          .then((friendRequests) => {
            sendJsonResponse(response, {
              status: "success",
              friendRequests: friendRequests,
            });
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  getPosts(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { search } = request.body,
          postsCollection = database.collection(DatabaseCollections.Posts);
        postsCollection
          .find({
            title: { $regex: `.*${search}.*` },
            deleted: false,
            $or: [
              { userId: currentUser._id },
              { visibility: PostVisibility.Public },
              {
                visibility: PostVisibility.Friends,
                userId: { $in: currentUser.friendsIds },
              },
              {
                visibility: PostVisibility.Followers,
                userId: { $in: currentUser.followingIds },
              },
              {
                visibility: PostVisibility.FriendsAndFollowers,
                $or: [
                  { userId: { $in: currentUser.friendsIds } },
                  { userId: { $in: currentUser.followingIds } },
                ],
              },
            ],
          })
          .toArray()
          .then((posts) => {
            sendJsonResponse(response, {
              status: "success",
              posts: posts,
            });
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  getPost(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { postId } = request.body,
          postsCollection = database.collection(DatabaseCollections.Posts);
        postsCollection
          .findOne({
            _id: getObjectID(postId),
            deleted: false,
            $or: [
              { userId: currentUser._id },
              { visibility: PostVisibility.Public },
              {
                visibility: PostVisibility.Friends,
                userId: { $in: currentUser.friendsIds },
              },
              {
                visibility: PostVisibility.Followers,
                userId: { $in: currentUser.followingIds },
              },
              {
                visibility: PostVisibility.FriendsAndFollowers,
                $or: [
                  { userId: { $in: currentUser.friendsIds } },
                  { userId: { $in: currentUser.followingIds } },
                ],
              },
            ],
          })
          .then((post) => {
            if (post) {
              sendJsonResponse(response, {
                status: "success",
                post: post,
              });
            } else {
              sendJsonResponse(response, {
                status: "error",
                message: "Error retrieving post!",
              });
            }
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  createPost(database = new Database(), request, response) {
    getCurrentUser(database, request, async (currentUser) => {
      if (currentUser) {
        let { title, text, visibility, videos, images } = request.body,
          postsCollection = database.collection(DatabaseCollections.Posts),
          mediaCollection = database.collection(DatabaseCollections.MediaFiles);
        let post = Post({
          title,
          text,
          visibility,
          user: {
            username: currentUser.username,
            profileImageId: currentUser.profileImageId,
          },
          userId: currentUser._id,
        });
        if (videos) {
          for (let video in videos) {
            let insertion = await mediaCollection.insertOne(video);
            post.videosIds.push(insertion.insertedId);
          }
        }
        if (images) {
          for (let image in images) {
            let insertion = await mediaCollection.insertOne(image);
            post.imagesIds.push(insertion.insertedId);
          }
        }
        postsCollection.insertOne(post).then((result) => {
          sendJsonResponse(response, {
            status: "success",
            message: "Post successful!",
            post: {
              ...post,
              _id: result.insertedId,
            },
          });
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  updatePost(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { postId } = request.body,
          { title, text, visibility, videos, images } = request.body,
          postsCollection = database.collection(DatabaseCollections.Posts);
        postsCollection
          .findOne({
            _id: getObjectID(postId),
            userId: currentUser._id,
            deleted: false,
          })
          .then(async (post) => {
            if (post) {
              if (videos) {
                for (let video in videos) {
                  let insertion = await mediaCollection.insertOne(video);
                  post.videosIds.push(insertion.insertedId);
                }
              }
              if (images) {
                for (let image in images) {
                  let insertion = await mediaCollection.insertOne(image);
                  post.imagesIds.push(insertion.insertedId);
                }
              }
              Object.assign(post, { title, text, visibility });
              postsCollection
                .updateOne({ _id: post._id }, { $set: post })
                .then((result) => {
                  sendJsonResponse(response, {
                    status: "success",
                    message: "Post update successful!",
                    post: post,
                  });
                });
            } else {
              sendJsonResponse(response, {
                status: "error",
                message: "Error retrieving post!",
              });
            }
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  deletePost(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { postId } = request.body,
          postsCollection = database.collection(DatabaseCollections.Posts);
        postsCollection
          .findOne({
            _id: getObjectID(postId),
            userId: currentUser._id,
            deleted: false,
          })
          .then((post) => {
            if (post) {
              post.deleted = true;
              postsCollection
                .updateOne({ _id: post._id }, { $set: post })
                .then((result) => {
                  sendJsonResponse(response, {
                    status: "success",
                    message: "Post deleted!",
                    post: post,
                  });
                });
            } else {
              sendJsonResponse(response, {
                status: "error",
                message: "Error retrieving post!",
              });
            }
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  createComment(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { text, postId, commentId } = request.body,
          commentsCollection = database.collection(
            DatabaseCollections.Comments
          );
        let comment = Comment({
          text,
          user: {
            username: currentUser.username,
            profileImageId: currentUser.profileImageId,
          },
          userId: currentUser._id,
        });
        commentsCollection.insertOne(comment).then((result) => {
          if (postId) {
            let postsCollection = database.collection(
              DatabaseCollections.Posts
            );
            postsCollection
              .findOne({ _id: getObjectID(postId) })
              .then((post) => {
                if (post) {
                  post.commentIds = [...post.commentsIds, result.insertedId];
                  postsCollection
                    .updateOne({ _id: post._id }, { $set: post })
                    .then((res) => {
                      sendJsonResponse(response, {
                        status: "success",
                        message: "Comment posted!",
                        comment: {
                          ...comment,
                          _id: result.insertedId,
                        },
                      });
                    });
                } else {
                  sendJsonResponse(response, {
                    status: "error",
                    message: "Error retrieving post!",
                  });
                }
              });
          } else if (commentId) {
            commentsCollection
              .findOne({ _id: getObjectID(commentId) })
              .then((comment) => {
                if (comment) {
                  comment.commentsIds = [
                    ...comment.commentsIds,
                    result.insertedId,
                  ];
                  commentsCollection
                    .updateOne({ _id: comment._id }, { $set: comment })
                    .then((result) => {
                      sendJsonResponse(response, {
                        status: "success",
                        message: "Comment posted!",
                        comment: {
                          ...comment,
                          _id: result.insertedId,
                        },
                      });
                    });
                } else {
                  sendJsonResponse(response, {
                    status: "error",
                    message: "Error retrieving comment!",
                  });
                }
              });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  deleteComment(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { commentId } = request.body,
          commentsCollection = database.collection(
            DatabaseCollections.Comments
          );
        commentsCollection
          .findOne({
            _id: getObjectID(commentId),
            userId: currentUser._id,
            deleted: false,
          })
          .then((comment) => {
            if (comment) {
              comment.deleted = true;
              commentsCollection
                .updateOne({ _id: comment._id }, { $set: comment })
                .then((result) => {
                  sendJsonResponse(response, {
                    status: "success",
                    message: "Comment deleted!",
                    comment: comment,
                  });
                });
            } else {
              sendJsonResponse(response, {
                status: "error",
                message: "Error retrieving comment!",
              });
            }
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  getPeople(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { search } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection
          .find({
            username: { $regex: `.*${search}.*` },
            deleted: false,
          })
          .toArray()
          .then((people) => {
            sendJsonResponse(response, {
              status: "success",
              people: people,
            });
          });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  getPerson(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection.findOne({ _id: getObjectID(userId) }).then((person) => {
          if (person) {
            // check profile visibility
            sendJsonResponse(response, {
              status: "success",
              person: person,
            });
          } else {
            sendJsonResponse(response, {
              status: "error",
              message: "Error retrieving user!",
            });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  followPerson(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection.findOne({ _id: getObjectID(userId) }).then((person) => {
          if (person) {
            person.followersIds = Array.from([
              ...currentUser.followersIds,
              currentUser._id,
            ]);
            currentUser.followingIds = Array.from([
              ...currentUser.followingIds,
              person._id,
            ]);
            usersCollection.updateOne({ _id: person._id }, { $set: person });
            usersCollection
              .updateOne({ _id: currentUser._id }, { $set: currentUser })
              .then((result) => {
                sendJsonResponse(response, {
                  status: "success",
                  message: "Follow successful.!",
                  user: currentUser,
                  person: person,
                });
              });
          } else {
            sendJsonResponse(response, {
              status: "error",
              message: "Error retrieving user!",
            });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  unfollowPerson(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection.findOne({ _id: getObjectID(userId) }).then((person) => {
          if (person) {
            person.followersIds = person.followersIds.filter((followerId) => {
              return followerId !== currentUser._id;
            });
            currentUser.followingIds = currentUser.followersIds.filter(
              (followingId) => {
                return followingId !== person._id;
              }
            );
            usersCollection.updateOne({ _id: person._id }, { $set: person });
            usersCollection
              .updateOne({ _id: currentUser._id }, { $set: currentUser })
              .then((result) => {
                sendJsonResponse(response, {
                  status: "success",
                  message: "Unfollow successful.!",
                  user: currentUser,
                  person: person,
                });
              });
          } else {
            sendJsonResponse(response, {
              status: "error",
              message: "Error retrieving user!",
            });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  blockPerson(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection.findOne({ _id: getObjectID(userId) }).then((person) => {
          if (person) {
            currentUser.blockedIds = Array.from([
              ...currentUser.blockedIds,
              person._id,
            ]);
            currentUser.friendsIds = currentUser.friendsIds.filter(
              (friendId) => {
                return friendId !== person._id;
              }
            );
            usersCollection
              .updateOne({ _id: currentUser._id }, { $set: currentUser })
              .then((result) => {
                sendJsonResponse(response, {
                  status: "success",
                  message: "Block successful.!",
                  user: currentUser,
                });
              });
          } else {
            sendJsonResponse(response, {
              status: "error",
              message: "Error retrieving user!",
            });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
  unblockPerson(database = new Database(), request, response) {
    getCurrentUser(database, request, (currentUser) => {
      if (currentUser) {
        let { userId } = request.body,
          usersCollection = database.collection(DatabaseCollections.Users);
        usersCollection.findOne({ _id: getObjectID(userId) }).then((person) => {
          if (person) {
            currentUser.blockedIds = currentUser.blockedIds.filter(
              (blockedId) => {
                return blockedId !== person._id;
              }
            );
            usersCollection
              .updateOne({ _id: currentUser._id }, { $set: currentUser })
              .then((result) => {
                sendJsonResponse(response, {
                  status: "success",
                  message: "Block successful.!",
                  user: currentUser,
                });
              });
          } else {
            sendJsonResponse(response, {
              status: "error",
              message: "Error retrieving user!",
            });
          }
        });
      } else {
        sendJsonResponse(response, {
          status: "error",
          message: "Unauthorized request!",
        });
      }
    });
  },
};
