import FX from "./fux/fux";

const {
  makePostJsonRequest,
  postFormData,
  EventModule,
  enableDevelopmentMode,
  disableDevelopmentMode,
  logConsole,
  cleanObject,
  validateEmailRE,
} = FX;

const ApplicationConstants = {
    ServerUrl: "http://127.0.0.1:8000/",
    JwtToken: "",
    LocalStorageKeys: {
      StoreState: "ApplicationStoreState",
    },
    ComponentsIds: {
      HomeWindow: "home_window",
      PeopleWindow: "people_window",
      RequestsWindow: "requests_window",
      SettingsWindow: "settings_window",
      AboutWindow: "about_window",
    },
  },
  Requests = {
    SignIn: "signIn",
    SignUp: "signUp",
    UpdateProfile: "updateProfile",
    DeleteAccount: "deleteAccount",
    CreateFriendRequest: "createFriendRequest",
    CancelFriendRequest: "cancelFriendRequest",
    AcceptFriendRequest: "acceptFriendRequest",
    RejectFriendRequest: "rejectFriendRequest",
    GetFriendRequests: "getFriendRequests",
    GetPosts: "getPosts",
    GetPost: "getPost",
    CreatePost: "createPost",
    UpdatePost: "updatePost",
    DeletePost: "deletePost",
    CreateComment: "createComment",
    DeleteComment: "deleteComment",
    GetPeople: "getPeople",
    GetPerson: "getPerson",
    FollowPerson: "followPerson",
    UnfollowPerson: "unfollowPerson",
    BlockPerson: "blockPerson",
    UnBlockPerson: "unblockPerson",
  };

function makeRequest(request, data) {
  return makePostJsonRequest(
    ApplicationConstants.ServerUrl,
    {
      ...data,
      request: request,
    },
    {
      Authorization: ApplicationConstants.JwtToken,
    },
    {},
    true
  );
}

const FXS = {
  ApplicationConstants: ApplicationConstants,
  DefaultStoreState: {
    user: null,
    posts: [],
    friendRequests: [],
    people: [],
    currentPost: null,
    currentPerson: null,
  },
  initialize() {
    enableDevelopmentMode();
  },
  signIn(data) {
    return makeRequest(Requests.SignIn, data);
  },
  signUp(data) {
    return makeRequest(Requests.SignUp, data);
  },
  updateProfile(data) {
    return makeRequest(Requests.UpdateProfile, data);
  },
  deleteAccount(data) {
    return makeRequest(Requests.DeleteAccount, data);
  },
  createFriendRequest(data) {
    return makeRequest(Requests.CreateFriendRequest, data);
  },
  cancelFriendRequest(data) {
    return makeRequest(Requests.CancelFriendRequest, data);
  },
  acceptFriendRequest(data) {
    return makeRequest(Requests.AcceptFriendRequest, data);
  },
  rejectFriendRequest(data) {
    return makeRequest(Requests.RejectFriendRequest, data);
  },
  getFriendRequests(data) {
    return makeRequest(Requests.GetFriendRequests, data);
  },
  getPosts(data) {
    return makeRequest(Requests.GetPosts, data);
  },
  getPost(data) {
    return makeRequest(Requests.GetPost, data);
  },
  createPost(data) {
    return makeRequest(Requests.CreatePost, data);
  },
  updatePost(data) {
    return makeRequest(Requests.UpdatePost, data);
  },
  deletePost(data) {
    return makeRequest(Requests.DeletePost, data);
  },
  createComment(data) {
    return makeRequest(Requests.CreateComment, data);
  },
  deleteComment(data) {
    return makeRequest(Requests.DeleteComment, data);
  },
  getPeople(data) {
    return makeRequest(Requests.GetPeople, data);
  },
  getPerson(data) {
    return makeRequest(Requests.GetPerson, data);
  },
  followPerson(data) {
    return makeRequest(Requests.FollowPerson, data);
  },
  unfollowPerson(data) {
    return makeRequest(Requests.UnfollowPerson, data);
  },
  blockPerson(data) {
    return makeRequest(Requests.BlockPerson, data);
  },
  unblockPerson(data) {
    return makeRequest(Requests.UnBlockPerson, data);
  },
  filterDuplicates(items, filterKey) {
    items.reverse;
    let found = [],
      filtered = items
        .map((item) => {
          if (found.includes(item[filterKey])) {
            return null;
          } else {
            found.push(item[filterKey]);
            return item;
          }
        })
        .filter((item) => {
          return item !== null;
        });
    filtered.reverse();
    return filtered;
  },
  successfulResponse(response) {
    return response.status === "success";
  },
};

export default FXS;
