const FUX = {
  developmentMode: true,
  async makeGetJsonRequest(url, headers, options, jsonify = true) {
    try {
      let requestOptions = {
          mode: "cors",
          method: "GET",
          headers: {
            Accept: "application/json",
            ...headers,
          },
          cache: "no-cache",
          ...options,
        },
        response = await fetch(url, requestOptions);
      if (jsonify === true) {
        response = await response.json();
        return response;
      } else {
        return response;
      }
    } catch (exception) {
      return {
        status: "error",
        exception: exception,
        message: exception.toString(),
      };
    }
  },
  async makePostJsonRequest(url, data, headers, options, jsonify = true) {
    try {
      let requestOptions = {
          mode: "cors",
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            ...headers,
          },
          cache: "no-cache",
          body: JSON.stringify(data),
          ...options,
        },
        response = await fetch(url, requestOptions);
      if (jsonify === true) {
        response = await response.json();
        return response;
      } else {
        return response;
      }
    } catch (exception) {
      return {
        status: "error",
        exception: exception,
        message: exception.toString(),
      };
    }
  },
  async postFormData(url, formData, headers, options, jsonify = true) {
    try {
      let requestOptions = {
          mode: "cors",
          method: "POST",
          headers: {
            Accept: "application/json",
            ...headers,
          },
          cache: "no-cache",
          body: formData,
          ...options,
        },
        response = await fetch(url, requestOptions);
      if (jsonify === true) {
        response = await response.json();
        return response;
      } else {
        return response;
      }
    } catch (exception) {
      return {
        status: "error",
        exception: exception,
        message: exception.toString(),
      };
    }
  },
  getUniqueId() {
    let x = 0;
    for (let q = 0; q < 10; ++q) {
      x += Date.now() * Math.random() * q;
    }
    return x.toString().replace(".", "");
  },
  getCookie(name) {
    let cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      let pair = cookies[i].split("=");
      if (name === pair[0].trim()) {
        return decodeURIComponent(pair[1]);
      }
    }
    return null;
  },
  isNull(object) {
    return object === nul || object === undefined || object === "";
  },
  notNull(object) {
    return !this.isNull(object);
  },
  isEmpty(object) {
    return Object.keys(object).length === 0;
  },
  cleanObject(object) {
    let newObject = {};
    Object.keys(object).map((key) => {
      let value = object[key];
      if (this.notNull(value)) {
        if (Array.isArray(value)) {
          newObject[key] = value;
        } else if (typeof value === typeof {}) {
          newObject[key] = this.cleanObject(value);
        } else {
          newObject[key] = value;
        }
      }
    });
    return newObject;
  },
  copyObject(object) {
    return Object.assign({}, object);
  },
  validateEmailRE(string) {
    return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(string);
  },
  enableDevelopmentMode() {
    this.developmentMode = true;
  },
  disableDevelopmentMode() {
    this.developmentMode = false;
  },
  logConsole(...data) {
    if (this.developmentMode !== true) {
      return;
    }
    return console.log(...data);
  },
  warnConsole(...data) {
    if (this.developmentMode !== true) {
      return;
    }
    return console.warn(...data);
  },
  errorConsole(...data) {
    if (this.developmentMode !== true) {
      return;
    }
    return console.error(...data);
  },
  EventModule: {
    addListener(event, listener) {
      window.addEventListener(event, listener);
      return this;
    },
    setListener(event, listener) {
      window["on" + event] = listener;
      return this;
    },
    removeListener(event, listener) {
      window.removeEventListener(event, listener);
      return this;
    },
    dispatchEvent(event, data) {
      window.dispatchEvent(new CustomEvent(event, { detail: data }));
      return this;
    },
  },
};

export default FUX;
