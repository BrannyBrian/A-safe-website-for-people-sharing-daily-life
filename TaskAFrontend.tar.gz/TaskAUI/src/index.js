import BootstrapX from "./bootstrapx/bootstrapx";
import FontawesomeX from "./fontawesomex/fontawesomex";
import UI from "./uix/uix";
import CPS from "./components";
import FXS from "./functions";
import "./index.css";

const {
  Application,
  Activity,
  VerticalLayout,
  FlowLayout,
  Label,
  Initialize,
  Store,
} = UI;

const { FaRegular, FaBrands, FaSolid } = FontawesomeX;

function startApplication() {
  let application = Application({
      baseElement: document.getElementById("base_element"),
    }),
    store = Store(FXS.DefaultStoreState);
  store.subscribe(() => {
    localStorage.setItem(
      FXS.ApplicationConstants.LocalStorageKeys.StoreState,
      JSON.stringify(store.getState())
    );
  });
  application.showActivity(CPS.SignInActivity(application, store));
  UI.showToast("Welcome to my social app.");
}

window.onload = () => {
  Initialize();
  FontawesomeX.setIconFunction((props) => {
    return UI.Icon(props);
  });
  BootstrapX.setIconFunction((props) => {
    return UI.Icon(props);
  });
  startApplication();
};
