import BootstrapX from "./bootstrapx/bootstrapx";
import FontawesomeX from "./fontawesomex/fontawesomex";
import UI from "./uix/uix";
import FXS from "./functions";
import "./index.css";

const {
  Application,
  Activity,
  VerticalLayout,
  HorizontalLayout,
  FlowLayout,
  Label,
  Initialize,
  TextInput,
  PasswordInput,
  FooterBar,
  NavigationBar,
  Button,
  ProgressIndicator,
  TextArea,
} = UI;

const { FaRegular, FaBrands, FaSolid } = FontawesomeX;

const { Person, House, People, Gear, Telegram, Search, Star } =
  BootstrapX.Icons;

const Styles = {
  AuthenticationActivity: {
    Activity: {
      justifyContent: "center",
      alignItems: "center",
      padding: "100px 50px 150px 50px",
    },
    Window: {
      border: "1px solid lightgray",
      borderRadius: "10px",
      padding: "10px",
      minWidth: "250px",
    },
    IconRow: {
      justifyContent: "center",
      alignItems: "center",
    },
    InputRow: {
      justifyContent: "center",
      padding: "5px",
    },
    Button: {
      padding: "5px",
      borderRadius: "10px",
      fontWeight: "bold",
      width: "150px",
    },
    Input: {
      color: "inherit",
      borderRadius: "5px",
      width: "200px",
    },
    Icon: {
      fontSize: "50px",
      margin: "5px",
    },
  },
  FooterBar: {
    Bar: {
      borderTop: "1px solid lightgray",
    },
    Icon: {
      fontSize: "35px",
      margin: "5px",
    },
  },
  NavigationBar: {
    Bar: {
      borderBottom: "1px solid lightgray",
    },
    SearchBar: {
      alignItems: "center",
    },
    SearchInput: {
      width: "150px",
      borderRadius: "5px",
    },
    SearchIcon: {
      fontSize: "20px",
      margin: "0px 5px 0px 5px",
    },
    Icon: {
      fontSize: "30px",
      margin: "5px 10px 5px 10px",
    },
  },
  Tile: {
    Tile: {
      borderBottom: "1px solid lightgray",
      padding: "5px",
      margin: "2px",
    },
    Icon: {
      fontSize: "50px",
      margin: "10px",
    },
    Button: {
      width: "100px",
      padding: "2px",
      borderRadius: "5px",
    },
    Titlebar: {
      alignItems: "center",
      justifyContent: "space-between",
      padding: "5px",
      fontWeight: "bold",
    },
    ContentSection: {},
    FooterBar: {
      alignItems: "center",
      justifyContent: "space-between",
      padding: "3px",
    },
  },
  Dialog: {
    Content: {
      padding: "5px",
      minWidth: "250px",
    },
    ContentRow: {
      alignItems: "center",
      justifyContent: "center",
    },
    Button: {
      width: "100px",
      padding: "2px",
      borderRadius: "5px",
    },
    Input: {
      color: "inherit",
      borderRadius: "5px",
      width: "200px",
      margin: "5px",
    },
  },
};

function showMessageDialog(message, title = "Message") {
  UI.showDialog({
    title: title,
    content: VerticalLayout(
      {
        style: {
          minHeight: "100px",
        },
      },
      ...[
        Label({
          style: { margin: "10px" },
          text: message,
        }),
      ]
    ),
  });
}

function showLoadingScreen(message) {
  let element = document.createElement("div");
  element.className = "loading-screen";
  element.id = "loading_screen";
  document.body.append(element);
  UI.Render(
    VerticalLayout(
      {
        style: {
          alignItems: "center",
        },
      },
      ...[
        ProgressIndicator({
          style: {
            width: "150px",
            height: "150px",
            margin: "15px",
          },
        }),
        Label({
          style: {
            color: "white",
            fontWeight: "bold",
            fontStyle: "italic",
          },
          text: message,
        }),
      ]
    ),
    element
  );
}

function hideLoadingScreen() {
  let element = document.getElementById("loading_screen");
  if (element) {
    element.parentElement.removeChild(element);
  }
}

function loadListItems(display, items, render) {
  UI.Render(
    UI.VerticalLayout(
      {},
      ...items.map((item) => {
        return render(item);
      })
    ),
    display
  );
}

function openHomeActivity(application, store) {
  application.showActivity(HomeActivity(application, store));
  let load = (display, posts) => {
    loadListItems(display, posts, (post) => {
      return HorizontalLayout(
        {
          style: Styles.Tile.Tile,
        },
        ...[
          Person({
            style: Styles.Tile.Icon,
          }),
          VerticalLayout(
            { style: {} },
            ...[
              HorizontalLayout(
                { style: Styles.Tile.Titlebar },
                ...[
                  Label({
                    style: {},
                    text: post.user.username,
                  }),
                ]
              ),
              HorizontalLayout(
                { style: Styles.Tile.ContentSection },
                ...[
                  Label({
                    style: {},
                    text: post.text,
                  }),
                ]
              ),
            ]
          ),
        ]
      );
    });
  };
  FXS.getPosts({ search: "" }).then((response) => {
    console.log(response);
    if (FXS.successfulResponse(response)) {
      let display = document.getElementById(
        FXS.ApplicationConstants.ComponentsIds.HomeWindow
      );
      if (display) {
        load(display, response.posts);
      }
    }
  });
  let display = document.getElementById(
    FXS.ApplicationConstants.ComponentsIds.HomeWindow
  );
  load(display, store.getState().posts);
}

function openPeopleActivity(application, store) {
  application.showActivity(PeopleActivity(application, store));
  let load = (display, people) => {
    loadListItems(display, people, (person) => {
      return HorizontalLayout(
        {
          style: Styles.Tile.Tile,
        },
        ...[
          Person({
            style: Styles.Tile.Icon,
          }),
          VerticalLayout(
            { style: {} },
            ...[
              HorizontalLayout(
                { style: Styles.Tile.Titlebar },
                ...[
                  Label({
                    style: {},
                    text: person.username,
                  }),
                ]
              ),
              HorizontalLayout(
                { style: Styles.Tile.ContentSection },
                ...[
                  Button({
                    style: Styles.Tile.Button,
                    text: "Add Friend",
                  }),
                ]
              ),
            ]
          ),
        ]
      );
    });
  };
  FXS.getPeople({ search: "" }).then((response) => {
    console.log(response);
    if (FXS.successfulResponse(response)) {
      let display = document.getElementById(
        FXS.ApplicationConstants.ComponentsIds.PeopleWindow
      );
      if (display) {
        load(display, response.people);
      }
    }
  });
  let display = document.getElementById(
    FXS.ApplicationConstants.ComponentsIds.PeopleWindow
  );
  load(display, store.getState().people);
}

function openRequestsActivity(application, store) {
  application.showActivity(RequestsActivity(application, store));
  let load = (display, friendRequests) => {
    loadListItems(display, friendRequests, (request) => {
      return HorizontalLayout(
        {
          style: Styles.Tile.Tile,
        },
        ...[
          Person({
            style: Styles.Tile.Icon,
          }),
          VerticalLayout(
            { style: {} },
            ...[
              HorizontalLayout(
                { style: Styles.Tile.Titlebar },
                ...[
                  Label({
                    style: {},
                    text: "Friend request from :" + request.sender.username,
                  }),
                ]
              ),
              HorizontalLayout(
                { style: Styles.Tile.ContentSection },
                ...[
                  Button({
                    style: Styles.Tile.Button,
                    text: "Accept",
                  }),
                  Button({
                    style: Styles.Tile.Button,
                    text: "Reject",
                  }),
                ]
              ),
            ]
          ),
        ]
      );
    });
  };
  FXS.getFriendRequests({ search: "" }).then((response) => {
    console.log(response);
    if (FXS.successfulResponse(response)) {
      let display = document.getElementById(
        FXS.ApplicationConstants.ComponentsIds.RequestsWindow
      );
      if (display) {
        load(display, response.friendRequests);
      }
    }
  });
  let display = document.getElementById(
    FXS.ApplicationConstants.ComponentsIds.RequestsWindow
  );
  load(display, store.getState().friendRequests);
}

function openSettingsActivity(application, store) {
  application.showActivity(SettingsActivity(application, store));
  //
}

function loadingTile() {
  return HorizontalLayout(
    {
      style: {
        alignItems: "center",
        justifyContent: "center",
      },
    },
    ...[
      ProgressIndicator({
        style: {
          width: "100px",
          margin: "15px",
        },
      }),
    ]
  );
}

function SignInActivity(application, store) {
  return Activity({
    content: HorizontalLayout(
      {
        style: Styles.AuthenticationActivity.Activity,
      },
      ...[
        VerticalLayout(
          {
            style: Styles.AuthenticationActivity.Window,
          },
          ...[
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.IconRow,
              },
              ...[
                Person({
                  style: Styles.AuthenticationActivity.Icon,
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "email",
                  id: "email_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                PasswordInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "password",
                  id: "password_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                Button({
                  style: Styles.AuthenticationActivity.Button,
                  text: "Sign In",
                  onClick: () => {
                    let email = document.getElementById("email_input").value,
                      password =
                        document.getElementById("password_input").value,
                      data = { email, password };
                    FXS.signIn(data).then((response) => {
                      if (FXS.successfulResponse(response)) {
                        UI.showToast(response.message);
                        store.setState({
                          user: response.user,
                          jwtToken: response.jwtToken,
                        });
                        FXS.ApplicationConstants.JwtToken = response.jwtToken;
                        openHomeActivity(application, store);
                      } else {
                        showMessageDialog(response.message);
                      }
                    });
                  },
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                Button({
                  style: Styles.AuthenticationActivity.Button,
                  text: "Sign Up",
                  onClick: () => {
                    application.showActivity(
                      SignUpActivity(application, store)
                    );
                  },
                }),
              ]
            ),
          ]
        ),
      ]
    ),
  });
}

function SignUpActivity(application, store) {
  return Activity({
    content: HorizontalLayout(
      {
        style: Styles.AuthenticationActivity.Activity,
      },
      ...[
        VerticalLayout(
          {
            style: Styles.AuthenticationActivity.Window,
          },
          ...[
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.IconRow,
              },
              ...[
                Person({
                  style: Styles.AuthenticationActivity.Icon,
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "first name",
                  id: "first_name_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "last name",
                  id: "last_name_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "email",
                  id: "email_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "username",
                  id: "username_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "address",
                  id: "address_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                TextInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "phone number",
                  id: "phone_number_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                PasswordInput({
                  style: Styles.AuthenticationActivity.Input,
                  placeholder: "password",
                  id: "password_input",
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                Button({
                  style: Styles.AuthenticationActivity.Button,
                  text: "Sign Up",
                  onClick: () => {
                    let email = document.getElementById("email_input").value,
                      password =
                        document.getElementById("password_input").value,
                      firstName =
                        document.getElementById("first_name_input").value,
                      lastName =
                        document.getElementById("last_name_input").value,
                      username =
                        document.getElementById("username_input").value,
                      country = document.getElementById("country_input").value,
                      address = document.getElementById("address_input").value,
                      phoneNumber =
                        document.getElementById("phone_number_input").value,
                      data = {
                        email,
                        password,
                        firstName,
                        lastName,
                        username,
                        country,
                        address,
                        phoneNumber,
                      };
                    FXS.signUp(data).then((response) => {
                      if (FXS.successfulResponse(response)) {
                        UI.showToast(response.message);
                        store.setState({
                          user: response.user,
                          jwtToken: response.jwtToken,
                        });
                        FXS.ApplicationConstants.JwtToken = response.jwtToken;
                        openHomeActivity(application, store);
                      } else {
                        showMessageDialog(response.message);
                      }
                    });
                  },
                }),
              ]
            ),
            HorizontalLayout(
              {
                style: Styles.AuthenticationActivity.InputRow,
              },
              ...[
                Button({
                  style: Styles.AuthenticationActivity.Button,
                  text: "Sign In",
                  onClick: () => {
                    application.showActivity(
                      SignInActivity(application, store)
                    );
                  },
                }),
              ]
            ),
          ]
        ),
      ]
    ),
  });
}

function ApplicationNavigationBar(application, store) {
  return NavigationBar({
    style: Styles.NavigationBar.Bar,
    content: [
      Star({
        style: Styles.NavigationBar.Icon,
      }),
      HorizontalLayout(
        {
          style: Styles.NavigationBar.SearchBar,
        },
        ...[
          TextInput({
            style: Styles.NavigationBar.SearchInput,
            placeholder: "search",
          }),
          Search({
            style: Styles.NavigationBar.SearchIcon,
          }),
        ]
      ),
    ],
  });
}

function ApplicationFooterBar(application, store) {
  return FooterBar(
    {
      style: Styles.FooterBar.Bar,
    },
    ...[
      House({
        style: Styles.FooterBar.Icon,
        onClick: () => {
          openHomeActivity(application, store);
        },
      }),
      People({
        style: Styles.FooterBar.Icon,
        onClick: () => {
          openPeopleActivity(application, store);
        },
      }),
      Telegram({
        style: Styles.FooterBar.Icon,
        onClick: () => {
          openRequestsActivity(application, store);
        },
      }),
      Gear({
        style: Styles.FooterBar.Icon,
        onClick: () => {
          openSettingsActivity(application, store);
        },
      }),
    ]
  );
}

function HomeActivity(application, store) {
  return Activity({
    content: VerticalLayout(
      { id: FXS.ApplicationConstants.ComponentsIds.HomeWindow },
      ...[loadingTile()]
    ),
    footerBar: ApplicationFooterBar(application, store),
    navigationBar: ApplicationNavigationBar(application, store),
  });
}

function PeopleActivity(application, store) {
  return Activity({
    content: VerticalLayout(
      { id: FXS.ApplicationConstants.ComponentsIds.PeopleWindow },
      ...[loadingTile()]
    ),
    footerBar: ApplicationFooterBar(application, store),
    navigationBar: ApplicationNavigationBar(application, store),
  });
}

function RequestsActivity(application, store) {
  return Activity({
    content: VerticalLayout(
      { id: FXS.ApplicationConstants.ComponentsIds.RequestsWindow },
      ...[loadingTile()]
    ),
    footerBar: ApplicationFooterBar(application, store),
  });
}

function showCreatePostDialog(application, store) {
  UI.showDialog({
    title: "Create Post",
    content: VerticalLayout(
      {
        style: {},
      },
      ...[
        TextInput({
          style: Styles.Dialog.Input,
          placeholder: "Title",
          id: "post_title_input",
        }),
        TextArea({
          style: Styles.Dialog.Input,
          rows: 5,
          placeholder: "text",
          id: "post_text_input",
        }),
        HorizontalLayout(
          {
            style: Styles.Dialog.ContentRow,
          },
          ...[
            Button({
              style: Styles.Dialog.Button,
              text: "Upload",
              onClick: () => {
                let title = document.getElementById("post_title_input").value,
                  text = document.getElementById("post_text_input").value,
                  date = { title, text };
                FXS.createPost(date).then((response) => {
                  if (FXS.successfulResponse(response)) {
                    store.setState({
                      posts: [...store.getState().posts, response.post],
                    });
                    openHomeActivity(application, store);
                  } else {
                    showMessageDialog(response.message);
                  }
                });
              },
            }),
          ]
        ),
      ]
    ),
  });
}

function SettingsActivity(application, store) {
  return Activity({
    content: VerticalLayout(
      { id: FXS.ApplicationConstants.ComponentsIds.SettingsWindow },
      ...[
        HorizontalLayout(
          {
            style: {},
          },
          ...[
            Button({
              text: "Create Post",
              style: Styles.AuthenticationActivity.Button,
              onClick: () => {
                showCreatePostDialog(application, store);
              },
            }),
          ]
        ),
      ]
    ),
    footerBar: ApplicationFooterBar(application, store),
  });
}

function AboutActivity(application, store) {
  return Activity({
    content: VerticalLayout(
      {},
      ...[
        Label({
          text: "About",
        }),
      ]
    ),
    footerBar: ApplicationFooterBar(application, store),
  });
}

const CPS = {
  SignInActivity,
  SignUpActivity,
  HomeActivity,
  PeopleActivity,
  RequestsActivity,
  SettingsActivity,
  AboutActivity,
  openHomeActivity,
  openPeopleActivity,
  openRequestsActivity,
};

export default CPS;
