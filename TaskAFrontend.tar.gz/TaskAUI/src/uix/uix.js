import "./uix.css";

const _events_ = {
  onabort: "",
  afterprint: "",
  animationcancel: "",
  animationend: "",
  animationiteration: "",
  animationstart: "",
  auxclick: "",
  beforeinput: "",
  beforeprint: "",
  beforeunload: "",
  blur: "",
  canplay: "",
  canplaythrough: "",
  change: "",
  click: "",
  close: "",
  contextmenu: "",
  copy: "",
  cuechange: "",
  cut: "",
  dblclick: "",
  drag: "",
  dragend: "",
  dragenter: "",
  dragexit: "",
  dragleave: "",
  dragover: "",
  dragstart: "",
  drop: "",
  durationchange: "",
  emptied: "",
  ended: "",
  error: "",
  focus: "",
  formdata: "",
  fullscreenchange: "",
  fullscreenerror: "",
  gamepadconnected: "",
  gamepaddisconnected: "",
  gotpointercapture: "",
  hashchange: "",
  input: "",
  invalid: "",
  keydown: "",
  keypress: "",
  keyup: "",
  languagechange: "",
  load: "",
  loadeddata: "",
  onloadedmetadata: "",
  loadstart: "",
  lostpointercapture: "",
  message: "",
  messageerror: "",
  mousedown: "",
  mousemove: "",
  mouseout: "",
  mouseover: "",
  mouseup: "",
  offline: "",
  online: "",
  pagehide: "",
  pageshow: "",
  paste: "",
  pause: "",
  play: "",
  playing: "",
  pointercancel: "",
  pointerdown: "",
  pointerenter: "",
  pointerleave: "",
  pointermove: "",
  pointerout: "",
  pointerover: "",
  pointerup: "",
  popstate: "",
  progress: "",
  ratechange: "",
  rejectionhandled: "",
  reset: "",
  resize: "",
  scroll: "",
  scrollend: "",
  securitypolicyviolation: "",
  seeked: "",
  seeking: "",
  select: "",
  selectionchange: "",
  selectstart: "",
  slotchange: "",
  stalled: "",
  storage: "",
  submit: "",
  suspend: "",
  timeupdate: "",
  toggle: "",
  transitioncancel: "",
  transitionend: "",
  transitionrun: "",
  transitionstart: "",
  unhandledrejection: "",
  unload: "",
  volumechange: "",
  waiting: "",
  webkitanimationend: "",
  webkitanimationiteration: "",
  webkitanimationstart: "",
  webkittransitionend: "",
  wheel: "",
};

function _initialize_events_() {
  Object.keys(_events_).map((event) => {
    _events_[event] = event;
  });
}

function _is_null_(item) {
  return item === null || item === undefined || item === "";
}

function _not_null_(item) {
  return !_is_null_(item);
}

function _nullify_(object) {
  object = null;
}

function _get_unique_id_() {
  let x = 0;
  for (let q = 0; q < 10; ++q) {
    x += Date.now() * Math.random();
  }
  return x.toString().replace(".", "");
}

function _is_svg_tag_(tag = "") {
  return [
    "svg",
    "path",
    "circle",
    "ellipse",
    "line",
    "polygon",
    "ployline",
    "rect",
  ].includes(tag);
}

function _is_valid_element_property_(key, value) {
  return (
    _not_null_(key) &&
    _not_null_(value) &&
    typeof value !== "function" &&
    typeof value !== "object"
  );
}

function _is_event_listener_(key) {
  return (
    key.length > 2 &&
    key.startsWith("on") &&
    Object.values(_events_).includes(key.toLowerCase().slice(2))
  );
}

function _create_element_(tag, properties, ...children) {
  let loadedChildren = [];
  loadedChildren = children
    .map((child) => {
      if (_not_null_(child)) {
        if (
          typeof child === "string" ||
          typeof child === "number" ||
          typeof child === "boolean"
        ) {
          let wrapped = _create_element_("span", {});
          wrapped.element.textContent = child.toString();
          return wrapped;
        } else if (child.isElement) {
          return child;
        } else {
          return null;
        }
      } else {
        return null;
      }
    })
    .filter((child) => {
      return _not_null_(child);
    });
  if (typeof tag === "string") {
    let element = _is_svg_tag_(tag)
        ? document.createElementNS("http://www.w3.org/2000/svg", tag)
        : document.createElement(tag),
      elementWrapper = {
        isElement: true,
        elementId: _get_unique_id_(),
        element: element,
        parent: null,
        children: loadedChildren,
        __mounted__: false,
        setParent(parent) {
          this.parent = parent;
        },
        _mounting_() {
          if (_not_null_(this.mounting)) {
            this.mounting();
          } else if (
            _not_null_(properties._hooks_) &&
            _not_null_(properties._hooks_.mounting)
          ) {
            properties._hooks_.mounting();
          }
          this.children.map((child) => {
            child._mounting_();
          });
        },
        async _mounted_() {
          this.__mounted__ = true;
          if (_not_null_(this.mounted)) {
            this.mounted();
          } else if (
            _not_null_(properties._hooks_) &&
            _not_null_(properties._hooks_.mounted)
          ) {
            properties._hooks_.mounted();
          }
          this.children.map((child) => {
            child._mounted_();
          });
        },
        _unmounting_() {
          if (_not_null_(this.unmounting)) {
            this.unmounting();
          } else if (
            _not_null_(properties._hooks_) &&
            _not_null_(properties._hooks_.unmounting)
          ) {
            properties._hooks_.unmounting();
          }
          this.children.map((child) => {
            child._unmounting_();
          });
        },
        async _unmounted_() {
          this.__mounted__ = false;
          if (_not_null_(this.unmounted)) {
            this.unmounted();
          } else if (
            _not_null_(properties._hooks_) &&
            _not_null_(properties._hooks_.unmounted)
          ) {
            properties._hooks_.unmounted();
          }
          this.children.map((child) => {
            child._unmounted_();
          });
        },
      };
    Object.keys(properties).map((key) => {
      if (key === "style") {
        Object.assign(element.style, properties[key]);
      } else if (
        key === "instanceReference" &&
        properties[key].isInstanceReference
      ) {
        properties.instanceReference.instance = element;
      } else if (_is_event_listener_(key)) {
        element.addEventListener(key.slice(2).toLowerCase(), properties[key]);
      } else if (_is_valid_element_property_(key, properties[key])) {
        element[key] = properties[key];
        element.setAttribute(key, properties[key]);
      }
    });
    loadedChildren.map((child) => {
      child.setParent(elementWrapper);
      element.appendChild(child.element);
    });
    return elementWrapper;
  } else if (typeof tag === "object" && tag.isComponent) {
    let wrapper = _create_component_instance_(tag, properties);
    return wrapper;
  } else {
    return null;
  }
}

function _create_component_(properties) {
  let component = {
    getInitialState() {
      return {};
    },
    getDefaultProps() {
      return {};
    },
    update() {
      return true;
    },
    updating() {},
    updated() {},
    mounting() {},
    mounted() {},
    unmounting() {},
    unmounted() {},
    render() {
      return _create_element_("div", {});
    },
    ...properties,
    isComponent: true,
    componentId: _get_unique_id_(),
  };
  return component;
}

function _create_component_instance_(component, properties) {
  let instance = {
    ...component,
    instanceId: _get_unique_id_(),
    state: {},
    props: {},
    getState() {
      return this.state;
    },
    getProps() {
      return this.props;
    },
    setState(state) {
      let previousState = this.getState(),
        newState = {
          ...previousState,
          ...state,
        },
        update = this.update(previousState, newState);
      this.state = newState;
      if (update === true) {
        this.updating();
        let previousElement = this.element,
          newElement = this.render(),
          temporaryElement = document.createElement("span");
        this.children.map((child) => {
          child._unmounting_();
        });
        newElement.children.map((child) => {
          child._mounting_();
        });
        previousElement.replaceWith(newElement.element);
        this.children.map((child) => {
          child._unmounted_();
        });
        Object.assign(this, {
          element: newElement.element,
          children: newElement.children,
        });
        this.children.map((child) => {
          child.setParent(this);
          child._mounted_();
        });
        this.updated();
      }
    },
    initialize() {
      this.props = {
        ...this.getDefaultProps(),
        ...properties,
      };
      this.state = this.getInitialState();
      Object.assign(this, this.render());
    },
  };
  instance.initialize();
  if (
    _not_null_(properties.instanceReference) &&
    properties.instanceReference.isInstanceReference
  ) {
    properties.instanceReference.instance = instance;
  }
  return instance;
}

function _render_(element, htmlElement) {
  element.setParent(htmlElement);
  htmlElement.innerHTML = "";
  element._mounting_();
  htmlElement.appendChild(element.element);
  element._mounted_();
}

function _instance_reference_() {
  return {
    isInstanceReference: true,
    instance: null,
  };
}

function _store_(state) {
  return {
    state: state,
    handlers: {},
    getState() {
      return this.state;
    },
    setState(state) {
      this.state = {
        ...this.state,
        ...state,
      };
      Object.values(this.handlers).map((handler) => {
        handler(this.state);
      });
    },
    subscribe(handler) {
      let handlerId = _get_unique_id_();
      this.handlers[handlerId] = handler;
      return handlerId;
    },
    unsubscribe(handlerId) {
      delete this.handlers[handlerId];
    },
  };
}

const _colors_ = {
  ALICE_BLUE: "#F0F8FF",
  ANTIQUE_WHITE: "#FAEBD7",
  AQUA: "#00FFFF",
  AQUAMARINE: "#7FFFD4",
  AZURE: "#F0FFFF",
  BEIGE: "#F5F5DC",
  BISQUE: "#FFE4C4",
  BLACK: "#000000",
  BLACK1: "#77767B",
  BLACK2: "#5E5C64",
  BLACK3: "#3D3846",
  BLACK4: "#241F31",
  BLACK5: "#000000",
  BLANCHED_ALMOND: "#FFEBCD",
  BLUE: "#0000FF",
  BLUE1: "#99C1F1",
  BLUE2: "#62A0EA",
  BLUE3: "#3584E4",
  BLUE4: "#1C71D8",
  BLUE5: "#1A5FB4",
  BLUE_GREEN: "#9DF9EF",
  BLUE_VIOLET: "#8A2BE2",
  BRIGHT_BLUE: "#51E2F5",
  BROWN: "#A52A2A",
  BROWN1: "#CDAB8F",
  BROWN2: "#B5835A",
  BROWN3: "#986A44",
  BROWN4: "#865E3C",
  BROWN5: "#63452C",
  BURLY_WOOD: "#DEB887",
  BURNT_ORANGE: "#EE4E34",
  CADET_BLUE: "#5F9EA0",
  CHARCOAL: "#101820FF",
  CHARTREUSE: "#7FFF00",
  CHERRY_RED: "#990011FF",
  CHOCOLATE: "#D2691E",
  CLASSIC_BLUE: "#2F3C7E",
  CLASSIC_PINK: "#FBEAEB",
  CLASSIC_YELLOW: "#FEE715FF",
  CORAL: "#FF7F50",
  CORNFLOWER_BLUE: "#6495ED",
  CORNSILK: "#FFF8DC",
  CRIMSON: "#DC143C",
  CYAN: "#00FFFF",
  DARK_BLUE: "#00008B",
  DARK_CYAN: "#008B8B",
  DARK_GOLDEN_ROD: "#B8860B",
  DARK_GRAY: "#A9A9A9",
  DARK_GREEN: "#006400",
  DARK_GREY: "#A9A9A9",
  DARK_KHAKI: "#BDB76B",
  DARK_MAGENTA: "#8B008B",
  DARK_OLIVE_GREEN: "#556B2F",
  DARK_ORANGE: "#FF8C00",
  DARK_ORCHID: "#9932CC",
  DARK_RED: "#8B0000",
  DARK_SALMON: "#E9967A",
  DARK_SAND: "#A28089",
  DARK_SEA_GREEN: "#8FBC8F",
  DARK_SLATE_BLUE: "#483D8B",
  DARK_SLATE_GRAY: "#2F4F4F",
  DARK_SLATE_GREY: "#2F4F4F",
  DARK_TURQUOISE: "#00CED1",
  DARK_VIOLET: "#9400D3",
  DEEP_PINK: "#FF1493",
  DEEP_SKY_BLUE: "#00BFFF",
  DIM_GRAY: "#696969",
  DIM_GREY: "#696969",
  DODGER_BLUE: "#1E90FF",
  DUSTY_WHITE: "#EDF756",
  ELECTRIC_BLUE: "#4831D4",
  FIRE_BRICK: "#B22222",
  FLORAL_WHITE: "#FFFAF0",
  FOREST_GREEN: "#3A6B35",
  FREEZE_PURPLE: "#E5EAF5",
  FUCHSIA: "#FF00FF",
  GAINSBORO: "#DCDCDC",
  GHOST_WHITE: "#F8F8FF",
  GOLD: "#FFD700",
  GOLDEN_ROD: "#DAA520",
  GRAY: "#808080",
  GRAY1: "#FFFFFF",
  GRAY2: "#F6F5F4",
  GRAY3: "#DEDDDA",
  GRAY4: "#C0BFBC",
  GRAY5: "#9A9996",
  GREEN: "#008000",
  GREEN1: "#8FF0A4",
  GREEN2: "#57E3A9",
  GREEN3: "#33D17A",
  GREEN4: "#2EC27E",
  GREEN5: "#26A269",
  GREEN_YELLOW: "#ADFF2F",
  GREY: "#808080",
  HEAVY_PURPLE: "#A28089",
  HONEY_DEW: "#F0FFF0",
  HOT_PINK: "#FF69B4",
  ICE_COLD: "#A0D2EB",
  INDIAN_RED: "#CD5C5C",
  INDIGO: "#1E2761",
  ISLAND_GREEN: "#2BAE66FF",
  IVORY: "#FFFFF0",
  KHAKI: "#F0E68C",
  LAVENDER: "#E2D1F9",
  LAVENDER_BLUSH: "#FFF0F5",
  LAWN_GREEN: "#7CFC00",
  LEMON_CHIFFON: "#FFFACD",
  LIGHT_BLUE: "#ADD8E6",
  LIGHT_CORAL: "#F08080",
  LIGHT_CYAN: "#E0FFFF",
  LIGHT_GOLDEN_ROD_YELLOW: "#FAFAD2",
  LIGHT_GRAY: "#D3D3D3",
  LIGHT_GREEN: "#90EE90",
  LIGHT_GREY: "#D3D3D3",
  LIGHT_OLIVE: "#E7E8D1",
  LIGHT_PINK: "#FFB6C1",
  LIGHT_SALMON: "#FFA07A",
  LIGHT_SEA_GREEN: "#20B2AA",
  LIGHT_SKY_BLUE: "#87CEFA",
  LIGHT_SLATE_GRAY: "#778899",
  LIGHT_SLATE_GREY: "#778899",
  LIGHT_STEEL_BLUE: "#B0C4DE",
  LIGHT_TEAL: "#A7BEAE",
  LIGHT_YELLOW: "#FFFFE0",
  LIME: "#00FF00",
  LIME_GREEN: "#CCF381",
  LINEN: "#FAF0E6",
  MAGENTA: "#FF00FF",
  MAROON: "#7A2048",
  MEDIUM_AQUA_MARINE: "#66CDAA",
  MEDIUM_BLUE: "#0000CD",
  MEDIUM_ORCHID: "#BA55D3",
  MEDIUM_PURPLE: "#D0BDF4",
  MEDIUM_SEA_GREEN: "#3CB371",
  MEDIUM_SLATE_BLUE: "#7B68EE",
  MEDIUM_SPRING_GREEN: "#00FA9A",
  MEDIUM_TURQUOISE: "#48D1CC",
  MEDIUM_VIOLET_RED: "#C71585",
  MIDNIGHT_BLUE: "#191970",
  MINT_CREAM: "#F5FFFA",
  MISTY_ROSE: "#FFE4E1",
  MOCCASIN: "#FFE4B5",
  MUSTARD: "#E3B448",
  NAVAJO_WHITE: "#FFDEAD",
  NAVY: "#000080",
  OFF_WHITE: "#FCF6F5FF",
  OLD_LACE: "#FDF5E6",
  OLIVE: "#808000",
  OLIVE_DRAB: "#6B8E23",
  ORANGE: "#FFA500",
  ORANGE1: "#FFBE6F",
  ORANGE2: "#FFA348",
  ORANGE3: "#FF7800",
  ORANGE4: "#E66100",
  ORANGE5: "#C64600",
  ORANGE_RED: "#FF4500",
  ORCHID: "#DA70D6",
  PALE_GOLDEN_ROD: "#EEE8AA",
  PALE_GREEN: "#98FB98",
  PALE_TURQUOISE: "#AFEEEE",
  PALE_VIOLET_RED: "#DB7093",
  PAPAYA_WHIP: "#FFEFD5",
  PEACH: "#EEA47FFF",
  PEACH_PUFF: "#FFDAB9",
  PERU: "#CD853F",
  PINK: "#FFC0CB",
  PINK_SAND: "#FFA8B6",
  PLUM: "#DDA0DD",
  POWDER_BLUE: "#B0E0E6",
  PURPLE: "#800080",
  PURPLE1: "#DC8ADD",
  PURPLE2: "#C061CB",
  PURPLE3: "#9141AC",
  PURPLE4: "#813D9C",
  PURPLE5: "#613583",
  PURPLE_PAIN: "#8458B3",
  RASPBERRY: "#8A307F",
  REBECCA_PURPLE: "#663399",
  RED: "#FF0000",
  RED1: "#F66151",
  RED2: "#ED333B",
  RED3: "#E01B24",
  RED4: "#C01C28",
  RED5: "#A51D2D",
  ROSY_BROWN: "#BC8F8F",
  ROYAL_BLUE: "#00539CFF",
  SADDLE_BROWN: "#8B4513",
  SAGE: "#CBD18F",
  SALMON: "#FA8072",
  SANDY_BROWN: "#F4A460",
  SCARLET: "#B85042",
  SEA_GREEN: "#2E8B57",
  SEA_SHELL: "#FFF5EE",
  SIENNA: "#A0522D",
  SILVER: "#C0C0C0",
  SKY_BLUE: "#87CEEB",
  SLATE_BLUE: "#6A5ACD",
  SLATE_GRAY: "#708090",
  SLATE_GREY: "#708090",
  SNOW: "#FFFAFA",
  SPICED_APPLE: "#783937FF",
  SPRING_GREEN: "#00FF7F",
  STEEL_BLUE: "#4682B4",
  TAN: "#D2B48C",
  TEAL: "#317773",
  THISTLE: "#D8BFD8",
  TOMATO: "#FF6347",
  TURQUOISE: "#40E0D0",
  VERDANT_GREEN: "#2C5F2DFF",
  VIOLET: "#EE82EE",
  WHEAT: "#F5DEB3",
  WHITE: "#FFFFFF",
  WHITE1: "#9A9996",
  WHITE2: "#C0BFBC",
  WHITE3: "#DEDDDA",
  WHITE4: "#F6F5F4",
  WHITE5: "#FFFFFF",
  WHITE_SMOKE: "#F5F5F5",
  YELLOW: "#FFFF00",
  YELLOW1: "#F9F06B",
  YELLOW2: "#F8E45C",
  YELLOW3: "#F6D32D",
  YELLOW4: "#F5C211",
  YELLOW5: "#E5A50A",
  YELLOW_GREEN: "#9ACD32",
};

const _animation_classes_ = {
    PULSATING: "",
    SPINNING: "",
    SLIDE_IN_LEFT: "",
    SLIDE_IN_LEFT_SLOW: "",
    SLIDE_IN_LEFT_FAST: "",
    SLIDE_OUT_LEFT: "",
    SLIDE_OUT_LEFT_SLOW: "",
    SLIDE_OUT_LEFT_FAST: "",
    SLIDE_IN_RIGHT: "",
    SLIDE_IN_RIGHT_SLOW: "",
    SLIDE_IN_RIGHT_FAST: "",
    SLIDE_OUT_RIGHT: "",
    SLIDE_OUT_RIGHT_SLOW: "",
    SLIDE_OUT_RIGHT_FAST: "",
    SLIDE_IN_TOP: "",
    SLIDE_IN_TOP_SLOW: "",
    SLIDE_IN_TOP_FAST: "",
    SLIDE_OUT_TOP: "",
    SLIDE_OUT_TOP_FAST: "",
    SLIDE_OUT_TOP_SLOW: "",
    SLIDE_IN_BOTTOM: "",
    SLIDE_IN_BOTTOM_SLOW: "",
    SLIDE_IN_BOTTOM_FAST: "",
    SLIDE_OUT_BOTTOM: "",
    SLIDE_OUT_BOTTOM_SLOW: "",
    SLIDE_OUT_BOTTOM_FAST: "",
  },
  _classes_ = {
    ..._animation_classes_,
    HIDDEN: "",
    BUTTON: "",
    ICON_BUTTON: "",
    LABEL: "",
    PARAGRAPH: "",
    ICON: "",
    HEADING: "",
    LINK: "",
    IMAGE_VIEW: "",
    VIDEO_VIEW: "",
    AUDIO_VIEW: "",
    TEXT_INPUT: "",
    NUMBER_INPUT: "",
    WEEK_INPUT: "",
    TIME_INPUT: "",
    MONTH_INPUT: "",
    DATETIME_INPUT: "",
    DATE_INPUT: "",
    TEXT_AREA: "",
    PASSWORD_INPUT: "",
    COLOR_INPUT: "",
    FILE_INPUT: "",
    SELECTION: "",
    OPTION: "",
    SELECTION_VIEW: "",
    SELECTION_VIEW_ACTIVE: "",
    SELECTION_VIEW_DROPDOWN: "",
    OPTION_ITEM: "",
    PROGRESS_BAR: "",
    SLIDER: "",
    PROGRESS_INDICATOR: "",
    CHECK_BUTTON: "",
    CHECK_BUTTON_CHECK_BOX: "",
    CHECK_BUTTON_CHECK_BOX_CHECKED: "",
    RADIO_GROUP: "",
    VERTICAL_RADIO_GROUP: "",
    RADIO_BUTTON: "",
    RADIO_BUTTON_CHECK_BOX: "",
    RADIO_BUTTON_CHECK_BOX_CHECKED: "",
    SWITCH: "",
    SWITCH_ACTIVE: "",
    SWITCH_TOGGLE: "",
    SWITCH_TOGGLE_ACTIVE: "",
    MENU: "",
    MENU_ACTIVE: "",
    MENU_DROPDOWN: "",
    MENU_ITEM: "",
    MENU_BAR: "",
    TABBED_WINDOW: "",
    VERTICAL_TABBED_WINDOW: "",
    TABBED_WINDOW_TITLE_BAR: "",
    VERTICAL_TABBED_WINDOW_TITLE_BAR: "",
    TABBED_WINDOW_TITLE: "",
    TABBED_WINDOW_TITLE_ACTIVE: "",
    TABBED_WINDOW_CONTENT: "",
    TABBED_WINDOW_TITLE_BAR_CENTERED: "",
    TABBED_WINDOW_TITLE_BAR_SPACED: "",
    TABBED_WINDOW_TITLE_BAR_RIGHT: "",
    CANVAS: "",
    COLLAPSE_VIEW: "",
    COLLAPSE_VIEW_TITLE_BAR: "",
    COLLAPSE_VIEW_TITLE_BAR_ACTIVE: "",
    COLLAPSE_VIEW_CONTENT: "",
    ORDERED_LIST: "",
    UNORDERED_LIST: "",
    LIST_ITEM: "",
    TABLE: "",
    TABLE_HEADING: "",
    TABLE_FOOTER: "",
    TABLE_BODY: "",
    TABLE_ROW: "",
    TABLE_DATA: "",
    TABLE_HEADER: "",
    CAPTION: "",
    EMBED: "",
    IFRAME: "",
    VERTICAL_LAYOUT: "",
    HORIZONTAL_LAYOUT: "",
    FLOW_LAYOUT: "",
    GRID_LAYOUT: "",
    RELATIVE_LAYOUT: "",
    SCROLL_WINDOW: "",
    VERTICAL_SCROLL_WINDOW: "",
    HORIZONTAL_SCROLL_WINDOW: "",
    NAVIGATION_BAR: "",
    NAVIGATION_BAR_NAVIGATION_WINDOW: "",
    NAVIGATION_BAR_DRAWER_WINDOW: "",
    NAVIGATION_BAR_MENU_WINDOW: "",
    FOOTER_BAR: "",
    ACTIVITY: "",

    DIALOG: "",
    DIALOG_TITLE: "",
    DIALOG_WINDOW: "",
    DIALOG_TITLE_BAR: "",
    NOTIFICATION: "",
    TOAST: "",
  };

function _initialize_classes_() {
  Object.keys(_classes_).map((_class_) => {
    let value = "" + _class_;
    while (value.includes("_")) {
      value = value.replace("_", "-");
    }
    _classes_[_class_] = value.toLowerCase();
  });
}

function _get_window_dimensions_() {
  return {
    innerHeight: window.innerHeight,
    innerWidth: window.innerWidth,
    outerHeight: window.outerHeight,
    outerWidth: window.outerWidth,
  };
}

function _get_element_dimensions_(element) {
  return {
    clientWidth: element.clientWidth,
    clientHeight: element.clientHeight,
    offsetWidth: element.offsetWidth,
    offsetHeight: element.offsetHeight,
    offsetTop: element.offsetTop,
    offsetLeft: element.offsetLeft,
  };
}

function _load_content_(content) {
  return _is_null_(content) ? [] : Array.isArray(content) ? content : [content];
}

function _remove_fields_(object, fields) {
  let newObject = {};
  Object.keys(object)
    .filter((field) => {
      return fields.includes(field) !== true;
    })
    .map((field) => {
      newObject[field] = object[field];
    });
  return newObject;
}

const _selection_view_ = _create_component_({
  getInitialState() {
    return {
      selection: null,
      open: false,
    };
  },
  getDefaultProps() {
    return {
      optionItems: [],
      onInput: () => {},
      dropdownStyle: {},
      optionItemStyle: {},
    };
  },
  toggle() {
    this.setState({
      open: !this.getState().open,
    });
  },
  close() {
    if (this.getState().open === true) {
      this.setState({
        open: false,
      });
    }
  },
  open() {
    if (this.getState().open !== true) {
      this.setState({
        open: true,
      });
    }
  },
  setOption(item) {
    this.setState({
      selection: item,
      open: false,
    });
    this.props.onInput(item.value);
  },
  mounted() {
    window.addEventListener(_custom_events_.WINDOW_CLICK, () => {
      this.close();
    });
    window.addEventListener(_custom_events_.WINDOW_SCROLL, () => {
      this.close();
    });
  },
  unmounting() {
    window.removeEventListener(_custom_events_.WINDOW_CLICK, () => {
      this.close();
    });
    window.removeEventListener(_custom_events_.WINDOW_SCROLL, () => {
      this.close();
    });
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      selection = state.selection,
      optionItems = _load_content_(props.optionItems),
      component = this;
    return _create_element_(
      "div",
      {
        className:
          (props.className || "") +
          " " +
          (state.open === true
            ? _classes_.SELECTION_VIEW_ACTIVE
            : _classes_.SELECTION_VIEW),
        onClick: (event) => {
          event.stopPropagation();
          component.toggle();
        },
        ..._remove_fields_(props, ["className"]),
      },
      _is_null_(selection) ? "Select" : selection.text || "Select",
      state.open !== true
        ? null
        : _create_element_(
            "div",
            {
              className: _classes_.SELECTION_VIEW_DROPDOWN,
              style: props.dropdownStyle,
            },
            ...optionItems.map((item) => {
              return _create_element_(
                "div",
                {
                  className: _classes_.OPTION_ITEM,
                  style: props.optionItemStyle,
                  onClick: (event) => {
                    event.stopPropagation();
                    component.setOption(item);
                  },
                },
                item.content || item.text || "Option"
              );
            })
          )
    );
  },
});

const _switch_ = _create_component_({
  getInitialState() {
    return {
      active: false,
    };
  },
  getDefaultProps() {
    return {
      onActiveChange: () => {},
    };
  },
  toggle() {
    let active = this.getState().active;
    this.setState({
      active: !active,
    });
    this.props.onActiveChange(!active);
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      active = state.active,
      component = this;
    return _create_element_(
      "div",
      {
        className:
          (props.className || "") +
          " " +
          (active === true ? _classes_.SWITCH_ACTIVE : _classes_.SWITCH),
        onClick: (event) => {
          event.stopPropagation();
          component.toggle();
        },
        ..._remove_fields_(props, ["className"]),
      },
      _create_element_("div", {
        className:
          active === true
            ? _classes_.SWITCH_TOGGLE_ACTIVE
            : _classes_.SWITCH_TOGGLE,
      })
    );
  },
});

const _check_button_ = _create_component_({
  getInitialState() {
    return {
      checked: false,
    };
  },
  getDefaultProps() {
    return {
      text: "Ckeck",
      onCheckedChange: () => {},
    };
  },
  toggle() {
    let checked = this.getState().checked;
    this.setState({
      checked: !checked,
    });
    this.props.onCheckedChange(!checked);
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      checked = state.checked,
      component = this;
    return _create_element_(
      "div",
      {
        className: (props.className || "") + " " + _classes_.CHECK_BUTTON,
        onClick: (event) => {
          event.stopPropagation();
          component.toggle();
        },
        ..._remove_fields_(props, ["className"]),
      },
      _create_element_("div", {
        className:
          checked === true
            ? _classes_.CHECK_BUTTON_CHECK_BOX_CHECKED
            : _classes_.CHECK_BUTTON_CHECK_BOX,
      }),
      props.text
    );
  },
});

const _radio_group_ = _create_component_({
  getInitialState() {
    return {
      checked: {
        text: "",
        value: "",
      },
    };
  },
  getDefaultProps() {
    return {
      radioItems: [],
      vertical: false,
      onCheckedChange: () => {},
      radioButtonStyle: {},
    };
  },
  setChecked(item) {
    this.setState({
      checked: item,
    });
    this.props.onCheckedChange(item.value);
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      checked = state.checked,
      radioItems = _load_content_(props.radioItems),
      component = this;
    return _create_element_(
      "div",
      {
        className:
          (props.className || "") +
          " " +
          (props.vertical === true
            ? _classes_.VERTICAL_RADIO_GROUP
            : _classes_.RADIO_GROUP),
        ..._remove_fields_(props, ["className"]),
      },
      ...radioItems.map((item) => {
        return _create_element_(
          "div",
          {
            className: _classes_.RADIO_BUTTON,
            onClick: (event) => {
              event.stopPropagation();
              component.setChecked(item);
            },
            style: props.radioButtonStyle,
          },
          _create_element_("div", {
            className:
              item.value === checked.value
                ? _classes_.RADIO_BUTTON_CHECK_BOX_CHECKED
                : _classes_.RADIO_BUTTON_CHECK_BOX,
          }),
          item.text
        );
      })
    );
  },
});

const _menu_ = _create_component_({
  getInitialState() {
    return {
      open: false,
    };
  },
  getDefaultProps() {
    return {
      menuItems: [],
      title: "Menu",
      dropdownStyle: {},
      menuItemStyle: {},
    };
  },
  toggle() {
    if (this.getState().open !== true) {
      window.dispatchEvent(
        new CustomEvent(_custom_events_.CLOSE_MENU_REQUEST, {
          detail: this.elementId,
        })
      );
    }
    this.setState({
      open: !this.getState().open,
    });
  },
  close() {
    if (this.getState().open === true) {
      this.setState({
        open: false,
      });
    }
  },
  open() {
    if (this.getState().open !== true) {
      window.dispatchEvent(
        new CustomEvent(_custom_events_.CLOSE_MENU_REQUEST, {
          detail: this.elementId,
        })
      );
      this.setState({
        open: true,
      });
    }
  },
  mounted() {
    window.addEventListener(_custom_events_.WINDOW_CLICK, () => {
      this.close();
    });
    window.addEventListener(_custom_events_.WINDOW_SCROLL, () => {
      this.close();
    });
    window.addEventListener(_custom_events_.CLOSE_MENU_REQUEST, (event) => {
      if (event.detail.elementId !== this.elementId) {
        this.close();
      }
    });
  },
  unmounting() {
    window.removeEventListener(_custom_events_.WINDOW_CLICK, () => {
      this.close();
    });
    window.removeEventListener(_custom_events_.WINDOW_SCROLL, () => {
      this.close();
    });
    window.removeEventListener(_custom_events_.CLOSE_MENU_REQUEST, (event) => {
      if (event.detail.elementId !== this.elementId) {
        this.close();
      }
    });
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      menuItems = _load_content_(props.menuItems),
      component = this;
    return _create_element_(
      "div",
      {
        className:
          (props.className || "") +
          " " +
          (state.open === true ? _classes_.MENU_ACTIVE : _classes_.MENU),
        onClick: (event) => {
          event.stopPropagation();
          component.toggle();
        },
        ..._remove_fields_(props, ["className"]),
      },
      props.title,
      state.open !== true
        ? null
        : _create_element_(
            "div",
            {
              className: _classes_.MENU_DROPDOWN,
              style: props.dropdownStyle,
            },
            ...menuItems
          )
    );
  },
});

const _collapse_view_ = _create_component_({
  getInitialState() {
    return {
      open: true,
    };
  },
  getDefaultProps() {
    return {
      content: null,
      title: "Collapse",
      titleBarStyle: {},
      titleStyle: {},
      contentStyle: {},
    };
  },
  toggle() {
    this.setState({
      open: !this.getState().open,
    });
  },
  close() {
    this.setState({
      open: false,
    });
  },
  open() {
    this.setState({
      open: true,
    });
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      content = _load_content_(props.content),
      component = this;
    return _create_element_(
      "div",
      {
        className: (props.className || "") + " " + _classes_.COLLAPSE_VIEW,
        ..._remove_fields_(props, ["className"]),
      },
      _create_element_(
        "div",
        {
          className:
            state.open === true
              ? _classes_.COLLAPSE_VIEW_TITLE_BAR_ACTIVE
              : _classes_.COLLAPSE_VIEW_TITLE_BAR,
          onClick: (event) => {
            event.stopPropagation();
            component.toggle();
          },
          style: props.titleBarStyle,
        },
        props.title,
        state.open === true
          ? props.closeIcon || _create_element_("span", {}, "<")
          : props.openIcon || _create_element_("span", {}, ">")
      ),
      state.open !== true
        ? null
        : _create_element_(
            "div",
            {
              className: _classes_.COLLAPSE_VIEW_CONTENT,
              style: props.contentStyle,
            },
            ...content
          )
    );
  },
});

const _tabbed_window_ = _create_component_({
  getInitialState() {
    return {
      currentTabIndex: 0,
    };
  },
  getDefaultProps() {
    return {
      tabs: [],
      vertical: false,
      titleBarStyle: {},
      contentStyle: {},
      tabsLocation: "left",
    };
  },
  setCurrentTabIndex(index) {
    this.setState({
      currentTabIndex: index,
    });
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      tabs = _load_content_(props.tabs),
      tabsLocation = props.tabsLocation,
      currentTabIndex = state.currentTabIndex,
      currentTab = tabs.length > 0 ? tabs[currentTabIndex] : null,
      component = this;
    let titleBarClass =
      {
        left: _classes_.TABBED_WINDOW_TITLE_BAR,
        center: _classes_.TABBED_WINDOW_TITLE_BAR_CENTERED,
        right: _classes_.TABBED_WINDOW_TITLE_BAR_RIGHT,
      }[tabsLocation] || _classes_.TABBED_WINDOW_TITLE_BAR;
    return _create_element_(
      "div",
      {
        className:
          (props.className || "") +
          " " +
          (props.vertical === true
            ? _classes_.VERTICAL_TABBED_WINDOW
            : _classes_.TABBED_WINDOW),
        ..._remove_fields_(props, ["className"]),
      },
      _create_element_(
        "div",
        {
          className:
            props.vertical === true
              ? _classes_.VERTICAL_TABBED_WINDOW_TITLE_BAR
              : titleBarClass,
          style: props.titleBarStyle,
        },
        ...tabs.map((tab, index) => {
          return _create_element_(
            "div",
            {
              className:
                index === currentTabIndex
                  ? _classes_.TABBED_WINDOW_TITLE_ACTIVE
                  : _classes_.TABBED_WINDOW_TITLE,
              onClick: (event) => {
                event.stopPropagation();
                component.setCurrentTabIndex(index);
              },
              style: props.titleStyle,
            },
            tab.title
          );
        })
      ),
      _create_element_(
        "div",
        {
          className: _classes_.TABBED_WINDOW_CONTENT,
          style: props.contentStyle,
        },
        _is_null_(currentTab) ? null : currentTab.content
      )
    );
  },
});

const _navigation_bar_ = _create_component_({
  getInitialState() {
    return {
      drawerOpen: false,
      menuOpen: false,
    };
  },
  getDefaultProps() {
    return {
      drawerContent: null,
      menuContent: null,
      content: null,
      drawerButton: null,
      menuButton: null,
      navigationWindowStyle: {},
      drawerWindowStyle: {},
      menuWindowStyle: {},
    };
  },
  toggleDrawer() {
    this.setState({
      drawerOpen: !this.getState().drawerOpen,
      menuOpen: false,
    });
  },
  toggleMenu() {
    this.setState({
      menuOpen: !this.getState().menuOpen,
      drawerOpen: false,
    });
  },
  closeDrawer() {
    this.setState({
      drawerOpen: false,
    });
  },
  openDrawer() {
    this.setState({
      drawerOpen: true,
    });
  },
  closeMenu() {
    this.setState({
      menuOpen: false,
    });
  },
  openMenu() {
    this.setState({
      menuOpen: true,
    });
  },
  closeNavigation() {
    this.setState({
      drawerOpen: false,
      menuOpen: false,
    });
  },
  mounted() {
    let component = this;
    window.addEventListener(_custom_events_.CLOSE_DRAWERS_REQUEST, (event) => {
      component.setState({
        drawerOpen: false,
        menuOpen: false,
      });
    });
  },
  render() {
    let state = this.getState(),
      props = this.getProps(),
      drawerOpen = state.drawerOpen,
      menuOpen = state.menuOpen,
      drawerContent = _load_content_(props.drawerContent),
      menuContent = _load_content_(props.menuContent),
      drawerButton = props.drawerButton,
      menuButton = props.menuButton,
      content = _load_content_(props.content),
      component = this;
    return _create_element_(
      "div",
      {
        className: (props.className || "") + " " + _classes_.NAVIGATION_BAR,
        ..._remove_fields_(props, ["className"]),
      },
      drawerContent.length < 1
        ? null
        : _create_element_(
            "div",
            {
              onClick: (event) => {
                event.stopPropagation();
                component.toggleDrawer();
              },
            },
            _is_null_(drawerButton)
              ? _create_element_(
                  "div",
                  {
                    className: _classes_.BUTTON,
                  },
                  ">>>"
                )
              : drawerButton
          ),
      ...content,
      menuContent.length < 1
        ? null
        : _create_element_(
            "div",
            {
              onClick: (event) => {
                event.stopPropagation();
                component.toggleMenu();
              },
            },
            _is_null_(menuButton)
              ? _create_element_(
                  "div",
                  {
                    className: _classes_.BUTTON,
                  },
                  "<<<"
                )
              : menuButton
          ),
      (drawerContent.length < 1 && menuContent.length < 1) ||
        (drawerOpen === false && menuOpen === false)
        ? null
        : _create_element_(
            "div",
            {
              className: _classes_.NAVIGATION_BAR_NAVIGATION_WINDOW,
              onClick: (event) => {
                event.stopPropagation();
                component.closeNavigation();
              },
              style: props.navigationWindowStyle,
            },
            drawerOpen !== true
              ? null
              : _create_element_(
                  "div",
                  {
                    className: _classes_.NAVIGATION_BAR_DRAWER_WINDOW,
                    onClick: (event) => {
                      event.stopPropagation();
                    },
                    style: props.drawerWindowStyle,
                  },
                  ...drawerContent
                ),
            menuOpen !== true
              ? null
              : _create_element_(
                  "div",
                  {
                    className: _classes_.NAVIGATION_BAR_MENU_WINDOW,
                    onClick: (event) => {
                      event.stopPropagation();
                    },
                    style: props.menuWindowStyle,
                  },
                  ...menuContent
                )
          )
    );
  },
});

function _custom_element_(
  tag,
  customClass,
  customProperties,
  properties,
  ...children
) {
  let className = _not_null_(properties.className)
      ? [customClass, properties.className].join(" ")
      : customClass,
    style = {
      ...(customProperties.style || {}),
      ...(properties.style || {}),
    };
  return _create_element_(
    tag,
    {
      ...customProperties,
      ...properties,
      className: className,
      style: style,
    },
    ...children
  );
}

const _custom_events_ = {
  WINDOW_CLICK: "WINDOW_CLICK",
  WINDOW_SCROLL: "WINDOW_SCROLL",
  CLOSE_MENU_REQUEST: "CLOSE_MENU_REQUEST",
  CLOSE_DRAWERS_REQUEST: "CLOSE_DRAWERS_REQUEST",
};

function _initialize_() {
  _initialize_events_();
  _initialize_classes_();
  window.addEventListener("click", () => {
    window.dispatchEvent(new CustomEvent(_custom_events_.WINDOW_CLICK, {}));
  });
  window.addEventListener("scroll", () => {
    window.dispatchEvent(new CustomEvent(_custom_events_.WINDOW_SCROLL, {}));
  });
}

const UI = {
  Initialize() {
    _initialize_();
  },
  CreateElement(tag, properties, ...children) {
    return _create_element_(tag, properties, ...children);
  },
  CreateComponent(properties) {
    return _create_component_(properties);
  },
  Render(element, htmlElement) {
    return _render_(element, htmlElement);
  },
  InstanceReference() {
    return _instance_reference_();
  },
  Store(defaultState) {
    return _store_(defaultState);
  },
  Button(properties) {
    return _custom_element_(
      "div",
      _classes_.BUTTON,
      {},
      properties,
      properties.text
    );
  },
  IconButton(properties) {
    return _custom_element_(
      "div",
      _classes_.ICON_BUTTON,
      {},
      properties,
      properties.icon || null,
      properties.text
    );
  },
  Label(properties) {
    return _custom_element_(
      "span",
      _classes_.LABEL,
      {},
      properties,
      properties.text
    );
  },
  Paragraph(properties) {
    return _custom_element_(
      "p",
      _classes_.PARAGRAPH,
      {},
      properties,
      properties.text
    );
  },
  Icon(properties) {
    return _custom_element_("i", _classes_.ICON, {}, properties);
  },
  Heading1(properties) {
    return _custom_element_(
      "h1",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Heading2(properties) {
    return _custom_element_(
      "h2",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Heading3(properties) {
    return _custom_element_(
      "h3",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Heading4(properties) {
    return _custom_element_(
      "h4",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Heading5(properties) {
    return _custom_element_(
      "h5",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Heading6(properties) {
    return _custom_element_(
      "h6",
      _classes_.HEADING,
      {},
      properties,
      properties.text
    );
  },
  Link(properties, ...children) {
    return _custom_element_("a", _classes_.LINK, {}, properties, ...children);
  },
  ImageView(properties) {
    return _custom_element_("img", _classes_.IMAGE_VIEW, {}, properties);
  },
  VideoView(properties, ...children) {
    return _custom_element_(
      "video",
      _classes_.VIDEO_VIEW,
      {
        controls: true,
      },
      properties,
      ...children
    );
  },
  AudioView(properties, ...children) {
    return _custom_element_(
      "audio",
      _classes_.AUDIO_VIEW,
      {
        controls: true,
      },
      properties,
      ...children
    );
  },
  TextInput(properties) {
    return _custom_element_(
      "input",
      _classes_.TEXT_INPUT,
      {
        type: "text",
      },
      properties
    );
  },
  NumberInput(properties) {
    return _custom_element_(
      "input",
      _classes_.NUMBER_INPUT,
      {
        type: "number",
      },
      properties
    );
  },
  WeekInput(properties) {
    return _custom_element_(
      "input",
      _classes_.WEEK_INPUT,
      {
        type: "week",
      },
      properties
    );
  },
  TimeInput(properties) {
    return _custom_element_(
      "input",
      _classes_.TIME_INPUT,
      {
        type: "time",
      },
      properties
    );
  },
  MonthInput(properties) {
    return _custom_element_(
      "input",
      _classes_.MONTH_INPUT,
      {
        type: "month",
      },
      properties
    );
  },
  DatetimeInput(properties) {
    return _custom_element_(
      "input",
      _classes_.DATETIME_INPUT,
      {
        type: "datetime",
      },
      properties
    );
  },
  DateInput(properties) {
    return _custom_element_(
      "input",
      _classes_.DATE_INPUT,
      {
        type: "date",
      },
      properties
    );
  },
  TextArea(properties) {
    return _custom_element_(
      "textarea",
      _classes_.TEXT_AREA,
      {
        rows: 5,
      },
      properties
    );
  },
  PasswordInput(properties) {
    return _custom_element_(
      "input",
      _classes_.PASSWORD_INPUT,
      {
        type: "password",
      },
      properties
    );
  },
  ColorInput(properties) {
    return _custom_element_(
      "input",
      _classes_.COLOR_INPUT,
      {
        type: "color",
      },
      properties
    );
  },
  FileInput(properties) {
    return _custom_element_(
      "input",
      _classes_.FILE_INPUT,
      {
        type: "file",
      },
      properties
    );
  },
  Selection(properties, ...options) {
    return _custom_element_(
      "select",
      _classes_.SELECTION,
      {},
      properties,
      ...options
    );
  },
  Option(properties) {
    return _custom_element_("option", _classes_.OPTION, {}, properties);
  },
  ProgressBar(properties) {
    return _custom_element_("progress", _classes_.PROGRESS_BAR, {}, properties);
  },
  Slider(properties) {
    return _custom_element_(
      "input",
      _classes_.SLIDER,
      {
        type: "range",
      },
      properties
    );
  },
  ProgressIndicator(properties) {
    return _custom_element_(
      "div",
      _classes_.PROGRESS_INDICATOR,
      {},
      properties
    );
  },
  MenuBar(properties, ...menus) {
    return _custom_element_(
      "div",
      _classes_.MENU_BAR,
      {},
      properties,
      ...menus
    );
  },
  MenuItem(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.MENU_ITEM,
      {},
      properties,
      ...children
    );
  },
  Canvas(properties) {
    return _custom_element_("cavas", _classes_.CANVAS, {}, properties);
  },
  UnorderedList(properties, ...listItems) {
    return _custom_element_(
      "ul",
      _classes_.UNORDERED_LIST,
      {},
      properties,
      ...listItems
    );
  },
  OrderedList(properties, ...listItems) {
    return _custom_element_(
      "ol",
      _classes_.ORDERED_LIST,
      {},
      properties,
      ...listItems
    );
  },
  ListItem(properties, ...children) {
    return _custom_element_(
      "li",
      _classes_.LIST_ITEM,
      {},
      properties,
      ...children
    );
  },
  Table(properties, ...children) {
    return _custom_element_(
      "table",
      _classes_.TABLE,
      {},
      properties,
      ...children
    );
  },
  TableHeading(properties, ...children) {
    return _custom_element_(
      "thead",
      _classes_.TABLE_HEADING,
      {},
      properties,
      ...children
    );
  },
  TableFooter(properties, ...children) {
    return _custom_element_(
      "tfoot",
      _classes_.TABLE_FOOTER,
      {},
      properties,
      ...children
    );
  },
  TableBody(properties, ...children) {
    return _custom_element_(
      "tbody",
      _classes_.TABLE_BODY,
      {},
      properties,
      ...children
    );
  },
  TableRow(properties, ...children) {
    return _custom_element_(
      "tr",
      _classes_.TABLE_ROW,
      {},
      properties,
      ...children
    );
  },
  TableData(properties, ...children) {
    return _custom_element_(
      "td",
      _classes_.TABLE_DATA,
      {},
      properties,
      ...children
    );
  },
  TableHeader(properties, ...children) {
    return _custom_element_(
      "th",
      _classes_.TABLE_HEADER,
      {},
      properties,
      ...children
    );
  },
  Caption(properties, ...children) {
    return _custom_element_(
      "caption",
      _classes_.CAPTION,
      {},
      properties,
      ...children
    );
  },
  Embed(properties, ...children) {
    return _custom_element_(
      "embed",
      _classes_.EMBED,
      {},
      properties,
      ...children
    );
  },
  Iframe(properties, ...children) {
    return _custom_element_(
      "iframe",
      _classes_.IFRAME,
      {},
      properties,
      ...children
    );
  },
  VerticalLayout(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.VERTICAL_LAYOUT,
      {},
      properties,
      ...children
    );
  },
  HorizontalLayout(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.HORIZONTAL_LAYOUT,
      {},
      properties,
      ...children
    );
  },
  FlowLayout(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.FLOW_LAYOUT,
      {},
      properties,
      ...children
    );
  },
  GridLayout(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.GRID_LAYOUT,
      {},
      properties,
      ...children
    );
  },
  RelativeLayout(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.RELATIVE_LAYOUT,
      {},
      properties,
      ...children
    );
  },
  ScrollWindow(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.SCROLL_WINDOW,
      {},
      properties,
      ...children
    );
  },
  VerticalScrollWindow(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.VERTICAL_SCROLL_WINDOW,
      {},
      properties,
      ...children
    );
  },
  HorizontalScrollWindow(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.HORIZONTAL_SCROLL_WINDOW,
      {},
      properties,
      ...children
    );
  },
  FooterBar(properties, ...children) {
    return _custom_element_(
      "div",
      _classes_.FOOTER_BAR,
      {},
      properties,
      ...children
    );
  },
  Activity(properties) {
    return _custom_element_(
      "div",
      _classes_.ACTIVITY,
      {
        style: {
          paddingTop: _is_null_(properties.navigationBar) ? "0px" : "50px",
          paddingBottom: _is_null_(properties.footerBar) ? "5px" : "60px",
        },
      },
      properties,
      ..._load_content_(properties.content),
      properties.footerBar,
      properties.navigationBar
    );
  },
  SelectionView(properties) {
    return _create_element_(_selection_view_, properties);
  },
  Switch(properties) {
    return _create_element_(_switch_, properties);
  },
  CheckButton(properties) {
    return _create_element_(_check_button_, properties);
  },
  RadioGroup(properties) {
    return _create_element_(_radio_group_, properties);
  },
  Menu(properties) {
    return _create_element_(_menu_, properties);
  },
  CollapseView(properties) {
    return _create_element_(_collapse_view_, properties);
  },
  TabbedWindow(properties) {
    return _create_element_(_tabbed_window_, properties);
  },
  NavigationBar(properties) {
    return _create_element_(_navigation_bar_, properties);
  },
  Application(properties) {
    let application = {
      baseElement: properties.baseElement || document.body,
      router:
        properties.router ||
        function () {
          return null;
        },
      showActivity(activity, title) {
        _render_(activity, this.baseElement);
        if (_not_null_(title)) {
          window.location.hash = title;
        }
      },
      openActivity(title) {
        window.location.hash = title;
      },
    };
    window.addEventListener("hashchange", () => {
      let title = window.location.hash.slice(1),
        activity = application.router(title);
      if (_not_null_(activity)) {
        application.showActivity(activity, null);
      }
    });
    return application;
  },
  showDialog(properties) {
    let content = _load_content_(properties.content),
      dialogId = _get_unique_id_();
    let baseElement = document.createElement("div"),
      element = _create_element_(
        "div",
        {
          className: _classes_.DIALOG,
          onClick: (event) => {
            event.stopPropagation();
          },
          style: properties.style || {},
        },
        properties.splash === true
          ? null
          : _create_element_(
              "div",
              {
                className: _classes_.DIALOG_TITLE_BAR,
                style: properties.titleBarStyle || {},
              },
              properties.icon || null,
              _create_element_(
                "span",
                {
                  className: _classes_.DIALOG_TITLE,
                },
                properties.title || "..."
              ),
              properties.closeButton ||
                _create_element_(
                  "div",
                  {
                    className: _classes_.BUTTON,
                    onClick: (event) => {
                      event.stopPropagation();
                      this.closeDialog(dialogId);
                    },
                  },
                  "close"
                )
            ),
        ...content
      );
    baseElement.classList.add(_classes_.DIALOG_WINDOW);
    baseElement.setAttribute("dialog-id", dialogId);
    baseElement.addEventListener("click", () => {
      this.closeDialog(dialogId);
    });
    document.body.appendChild(baseElement);
    _render_(element, baseElement);
    if (
      _not_null_(properties.duration) &&
      typeof properties.duration === "number"
    ) {
      setTimeout(() => {
        this.closeDialog(dialogId);
      }, properties.duration);
    }
    return dialogId;
  },
  closeDialog(dialogId) {
    let element = document.querySelector(`[dialog-id="${dialogId}"]`);
    if (_not_null_(element)) {
      element.parentNode.removeChild(element);
    }
  },
  showNotification(properties, duration = 3000) {
    let content = _load_content_(properties.content),
      notificationId = _get_unique_id_();
    let baseElement = document.createElement("div"),
      element = _create_element_(
        "div",
        {
          className: _classes_.NOTIFICATION,
          onClick: (event) => {
            event.stopPropagation();
          },
          ...properties,
        },
        ...content
      );
    baseElement.setAttribute("notification-id", notificationId);
    document.body.appendChild(baseElement);
    _render_(element, baseElement);
    setTimeout(() => {
      this.closeNotification(notificationId);
    }, duration);
    return notificationId;
  },
  closeNotification(notificationId) {
    let element = document.querySelector(
      `[notification-id="${notificationId}"]`
    );
    if (_not_null_(element)) {
      element.parentNode.removeChild(element);
    }
  },
  showToast(text, duration = 3000) {
    if (_is_null_(text)) {
      return;
    }
    let toastId = _get_unique_id_(),
      baseElement = document.createElement("div");
    baseElement.classList.add(_classes_.TOAST);
    baseElement.setAttribute("toast-id", toastId);
    baseElement.textContent = text;
    document.body.appendChild(baseElement);
    setTimeout(() => {
      this.closeToast(toastId);
    }, duration);
    return toastId;
  },
  closeToast(toastId) {
    let element = document.querySelector(`[toast-id="${toastId}"]`);
    if (_not_null_(element)) {
      element.parentNode.removeChild(element);
    }
  },
  closeDrawers() {
    window.dispatchEvent(
      new CustomEvent(_custom_events_.CLOSE_DRAWERS_REQUEST, { detail: {} })
    );
  },
  closeDialogs() {
    document.querySelectorAll("[dialog-id]").forEach((element) => {
      element.parentNode.removeChild(element);
    });
  },
  closeNotifications() {
    document.querySelectorAll("[notification-id]").forEach((element) => {
      element.parentNode.removeChild(element);
    });
  },
  closeToasts() {
    document.querySelectorAll("[toast-id]").forEach((element) => {
      element.parentNode.removeChild(element);
    });
  },
  getUniqueId() {
    return _get_unique_id_();
  },
  getWindowDimensions() {
    return _get_window_dimensions_();
  },
  getElementDimensions(element) {
    return _get_element_dimensions_(element);
  },
  Colors: _colors_,
  Classes: _classes_,
  Events: _events_,
};

export default UI;
